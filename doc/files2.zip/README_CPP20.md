# MCEE C++20 - Système de Phases Émotionnelles

## 📋 Vue d'ensemble

Implémentation C++20 complète du système de phases émotionnelles pour le MCEE (Modèle Complet d'Évaluation des États). Le système détecte automatiquement l'état mental à partir des 24 émotions et ajuste dynamiquement les coefficients MCEE.

## 🎯 Caractéristiques

- ✅ **8 phases émotionnelles** avec détection automatique
- ✅ **C++20 moderne** avec designated initializers, concepts prêts
- ✅ **Thread-safe** avec `std::mutex`
- ✅ **Hysteresis** anti-oscillation configurable
- ✅ **Transitions d'urgence** (Phase PEUR court-circuite le système)
- ✅ **Statistiques détaillées** par phase
- ✅ **Intégration RabbitMQ** complète
- ✅ **Tests unitaires** inclus

## 📦 Structure du projet

```
mcee_cpp20/
├── phase_types.hpp          # Types et structures de base
├── phase_config.hpp         # Configurations des 8 phases
├── phase_detector.hpp       # Interface du détecteur
├── phase_detector.cpp       # Implémentation
├── mcee_phase_monitor.cpp   # Moniteur intégré avec RabbitMQ
├── test_phase_detector.cpp  # Programme de tests
├── main.cpp                 # Programme de prédiction original
├── CMakeLists.txt           # Configuration CMake
└── README_CPP20.md          # Ce fichier
```

## 🚀 Compilation et installation

### Prérequis

```bash
# Ubuntu/Debian
sudo apt-get install cmake build-essential
sudo apt-get install librabbitmq-dev libboost-all-dev

# Installer SimpleAmqpClient
git clone https://github.com/alanxz/SimpleAmqpClient.git
cd SimpleAmqpClient
mkdir build && cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr/local
make -j$(nproc)
sudo make install
```

### Compilation

```bash
mkdir build && cd build
cmake ..
make -j$(nproc)
```

Cela génère 3 exécutables :
- `emotion` : Prédiction d'émotions (programme original)
- `mcee_phase_monitor` : Moniteur avec phases intégrées
- `test_phase_detector` : Tests du détecteur

### Installation système

```bash
sudo make install
```

Installe dans :
- Binaires → `/usr/local/bin/`
- Bibliothèque → `/usr/local/lib/`
- Headers → `/usr/local/include/mcee/`

## 📚 Utilisation

### 1. Test standalone du détecteur

```bash
./test_phase_detector
```

Exécute une batterie de tests avec différents profils émotionnels :
- Profil PEUR (votre exemple)
- Profil JOIE
- Profil SÉRÉNITÉ
- Profil EXPLORATION
- Test des transitions
- Test de l'hysteresis

### 2. Moniteur MCEE avec RabbitMQ

```bash
# Terminal 1: Démarrer RabbitMQ
cd rabbitmq
docker-compose up -d

# Terminal 2: Lancer le programme de prédiction original
cd build
./emotion

# Terminal 3: Lancer le moniteur de phases
./mcee_phase_monitor
```

Le moniteur :
- Reçoit les émotions via RabbitMQ
- Détecte automatiquement la phase
- Affiche les coefficients MCEE adaptés
- Donne des recommandations selon la phase
- Génère des statistiques

### 3. Utilisation en bibliothèque

```cpp
#include <mcee/phase_detector.hpp>

using namespace mcee;

int main() {
    // Créer le détecteur
    PhaseDetector detector(0.15,  // hysteresis_margin
                          30.0);  // min_phase_duration_seconds
    
    // Préparer les émotions
    EmotionMap emotions = {
        {"Peur", 0.927},
        {"Horreur", 0.838},
        {"Anxiété", 0.659},
        // ... toutes les 24 émotions
    };
    
    // Détection
    Phase current_phase = detector.detect_phase(emotions);
    
    // Récupérer la configuration
    const PhaseConfig& config = detector.get_phase_config();
    
    std::cout << "Phase: " << to_string(current_phase) << std::endl;
    std::cout << "α (feedback externe): " << config.alpha << std::endl;
    std::cout << "δ (souvenirs): " << config.delta << std::endl;
    
    // Analyse du profil
    EmotionalProfile profile = detector.analyze_emotional_profile(emotions);
    std::cout << "Valence: " << profile.valence << std::endl;
    std::cout << "Arousal: " << profile.arousal << std::endl;
    
    return 0;
}
```

## 🎭 Les 8 Phases

### Phase SÉRÉNITÉ (Baseline)
```cpp
PhaseConfig {
    .alpha = 0.25,  .beta = 0.15,  .gamma = 0.12,
    .delta = 0.30,  .theta = 0.10,
    .amyghaleon_threshold = 0.85,
    .priority = 1
}
```
- État d'équilibre
- Apprentissage optimal
- Sage prise de décision

### Phase JOIE
```cpp
PhaseConfig {
    .alpha = 0.40,  .beta = 0.25,  .gamma = 0.08,
    .delta = 0.35,  .theta = 0.05,
    .amyghaleon_threshold = 0.95,
    .learning_rate = 1.3
}
```
- Renforcement positif
- Apprentissage accéléré
- ⚠️ Sous-évaluation des risques

### Phase EXPLORATION
```cpp
PhaseConfig {
    .alpha = 0.35,  .beta = 0.10,  .gamma = 0.10,
    .delta = 0.25,  .theta = 0.15,
    .attention_focus = 0.8,
    .learning_rate = 1.5
}
```
- Apprentissage MAXIMAL
- Attention très focalisée
- État optimal pour nouveautés

### Phase ANXIÉTÉ
```cpp
PhaseConfig {
    .alpha = 0.40,  .beta = 0.30,  .gamma = 0.06,
    .delta = 0.45,  .theta = 0.08,
    .amyghaleon_threshold = 0.70
}
```
- Hypervigilance
- Biais négatif
- Activation souvenirs anxiogènes

### Phase PEUR ⚠️ (URGENCE)
```cpp
PhaseConfig {
    .alpha = 0.60,  // MAXIMAL
    .beta = 0.45,   // TRÈS ÉLEVÉ
    .gamma = 0.02,  // TRÈS LENT (persistant)
    .delta = 0.70,  // TRAUMAS DOMINANTS
    .theta = 0.02,  // SAGESSE QUASI ABSENTE
    .amyghaleon_threshold = 0.50,  // URGENCE FACILE
    .priority = 5   // PRIORITÉ MAXIMALE
}
```
- 🚨 **AMYGHALEON ACTIVÉ**
- Actions réflexes : FUITE/BLOCAGE
- Court-circuit du MCEE normal
- Traumas activés en masse
- Création trauma probable

### Phase TRISTESSE
```cpp
PhaseConfig {
    .alpha = 0.20,  .beta = 0.40,  .gamma = 0.05,
    .delta = 0.55,  .theta = 0.12,
    .learning_rate = 0.6
}
```
- Rumination
- Introspection possible
- Énergie basse

### Phase DÉGOÛT
```cpp
PhaseConfig {
    .alpha = 0.50,  .beta = 0.25,  .gamma = 0.08,
    .delta = 0.40,  .theta = 0.08,
    .priority = 4
}
```
- Évitement actif
- Apprentissage d'associations négatives
- ⚠️ Risque de généralisation

### Phase CONFUSION
```cpp
PhaseConfig {
    .alpha = 0.35,  .beta = 0.30,  .gamma = 0.15,
    .delta = 0.50,  .theta = 0.15
}
```
- Recherche d'information
- Sollicitation mémoire intense
- Hésitation décisionnelle

## 🔄 Système de transitions

### Règles

1. **Priorité** : Phase PEUR (priorité 5) peut court-circuiter toutes les autres
2. **Hysteresis** : Marge de 0.15 pour éviter les oscillations
3. **Durée minimale** : 30 secondes avant changement
4. **Urgence** : Peur > 0.85 OU Horreur > 0.8 → transition IMMÉDIATE

### Exemple de séquence

```
SÉRÉNITÉ (120s) → EXPLORATION (45s) → JOIE (60s) → ANXIÉTÉ (35s) → PEUR (15s)
                                                                        ↓
                                                              AMYGHALEON ACTIVÉ
```

## 🔧 API Principale

### PhaseDetector

```cpp
class PhaseDetector {
public:
    // Constructeur
    explicit PhaseDetector(
        double hysteresis_margin = 0.15,
        double min_phase_duration_seconds = 30.0
    );
    
    // Détection
    Phase detect_phase(const EmotionMap& emotions);
    
    // Accesseurs
    Phase get_current_phase() const;
    const PhaseConfig& get_phase_config() const;
    const PhaseConfig& get_phase_config(Phase phase) const;
    
    // Analyse
    EmotionalProfile analyze_emotional_profile(
        const EmotionMap& emotions
    ) const;
    
    // Statistiques
    PhaseStatistics get_statistics() const;
    std::vector<PhaseTransition> get_recent_transitions(size_t n = 5) const;
    double get_time_in_current_phase() const;
    
    // Configuration
    void set_hysteresis_margin(double margin);
    void set_min_phase_duration(double seconds);
    
    // Debug
    void display_status(const EmotionMap& emotions) const;
};
```

### Types principaux

```cpp
// Émotion
using EmotionMap = std::unordered_map<std::string, double>;

// Phases
enum class Phase {
    SERENITE, JOIE, EXPLORATION, ANXIETE,
    PEUR, TRISTESSE, DEGOUT, CONFUSION
};

// Configuration de phase
struct PhaseConfig {
    double alpha, beta, gamma, delta, theta;
    double amyghaleon_threshold;
    double memory_consolidation;
    double attention_focus;
    double learning_rate;
    int priority;
    std::string description;
};

// Transition
struct PhaseTransition {
    Phase from_phase;
    Phase to_phase;
    TimePoint timestamp;
    double duration_previous;
    EmotionMap trigger_emotions;
    std::string reason;
};

// Profil émotionnel
struct EmotionalProfile {
    double valence;      // [-1, +1]
    double arousal;      // [0, 1]
    double dominance;    // [-2, +2]
    double variance;
    std::string max_emotion;
    double max_value;
    double positive_mean;
    double negative_mean;
};
```

## 📊 Exemple de sortie

```
======================================================================
🎭 PHASE ÉMOTIONNELLE: PEUR
======================================================================
⏱️  Durée dans cette phase: 2.3s

📊 Émotions dominantes:
   Peur                      : 0.927 [██████████████████░░]
   Horreur                   : 0.838 [████████████████░░░░]
   Anxiété                   : 0.659 [█████████████░░░░░░░]

⚙️  Coefficients MCEE actifs:
   α (feedback externe)    : 0.60  ⚠️ MAXIMAL
   β (feedback interne)    : 0.45
   γ (décroissance)        : 0.02  ⚠️ TRÈS LENT
   δ (influence souvenirs) : 0.70  ⚠️ TRAUMAS DOMINANTS
   θ (sagesse)             : 0.02  ⚠️ QUASI ABSENTE

🎯 Seuils actifs:
   Amyghaleon : 0.50  ⚠️ URGENCE FACILE
   Consolidation : 0.80
   Attention : 0.95
   Apprentissage : 0.30

📜 Transitions récentes:
   SERENITE → PEUR (0.0s)
======================================================================

💡 RECOMMANDATIONS SYSTÈME:
──────────────────────────────────────────────────────────────────────
   🚨 ÉTAT CRITIQUE - AMYGHALEON ACTIF
   → Priorité: SÉCURITÉ IMMÉDIATE
   → Actions: FUITE / BLOCAGE / ÉVITEMENT
   → Souvenirs traumatiques activés
   → Apprentissage rationnel désactivé
   ⚠️  Risque de création de trauma
──────────────────────────────────────────────────────────────────────
```

## 🧪 Tests

### Lancer les tests

```bash
# Tests de base
./test_phase_detector

# Avec valgrind (détection de fuites mémoire)
valgrind --leak-check=full ./test_phase_detector

# Tests unitaires (si BUILD_TESTS=ON)
cmake .. -DBUILD_TESTS=ON
make
ctest
```

### Créer vos propres tests

```cpp
#include <mcee/phase_detector.hpp>

void test_custom_profile() {
    PhaseDetector detector;
    
    EmotionMap my_profile = {
        // ... vos valeurs
    };
    
    Phase phase = detector.detect_phase(my_profile);
    assert(phase == Phase::EXPECTED);
}
```

## 🔗 Intégration avec votre système

### Avec le module de prédiction existant

```cpp
// Dans votre boucle principale
PhaseDetector phase_detector;

while (true) {
    // 1. Recevoir émotions du module C++ de prédiction
    EmotionMap emotions = receive_emotions_from_rabbitmq();
    
    // 2. Détecter la phase
    Phase current_phase = phase_detector.detect_phase(emotions);
    
    // 3. Récupérer les coefficients adaptés
    const PhaseConfig& config = phase_detector.get_phase_config();
    
    // 4. Appliquer au MCEE
    mcee_engine.set_coefficients(
        config.alpha, config.beta, config.gamma,
        config.delta, config.theta
    );
    
    // 5. Vérifier Amyghaleon
    if (current_phase == Phase::PEUR) {
        amyghaleon.activate();
        // Actions d'urgence...
    }
    
    // 6. Traitement MCEE normal
    // ...
}
```

### Avec Neo4j (persistance)

```cpp
void save_transition_to_neo4j(const PhaseTransition& t) {
    // Pseudo-code - adaptez selon votre driver Neo4j
    neo4j.run(R"(
        CREATE (t:PhaseTransition {
            from_phase: $from,
            to_phase: $to,
            timestamp: datetime($ts),
            duration: $dur
        })
    )", {
        {"from", to_string(t.from_phase)},
        {"to", to_string(t.to_phase)},
        {"ts", format_timestamp(t.timestamp)},
        {"dur", t.duration_previous}
    });
}

// Dans votre boucle
auto transitions = detector.get_recent_transitions(1);
if (!transitions.empty()) {
    save_transition_to_neo4j(transitions.back());
}
```

## ⚙️ Configuration avancée

### Ajuster l'hysteresis

```cpp
// Pour éviter les oscillations rapides
detector.set_hysteresis_margin(0.20);  // Au lieu de 0.15

// Pour système plus réactif
detector.set_hysteresis_margin(0.10);
```

### Ajuster la durée minimale

```cpp
// Pour tests rapides
detector.set_min_phase_duration(5.0);  // 5 secondes

// Pour système plus stable
detector.set_min_phase_duration(60.0);  // 1 minute
```

### Modifier les seuils de détection

Éditez `phase_config.hpp` :

```cpp
{Phase::PEUR, {
    .func = [](const EmotionMap& e) {
        // Modifier le seuil ici
        return get_emotion(e, "Peur") > 0.75;  // Au lieu de 0.8
    },
    // ...
}}
```

## 📈 Monitoring et statistiques

```cpp
// Récupérer les stats
auto stats = detector.get_statistics();

std::cout << "Phase actuelle: " << to_string(stats.current_phase) << std::endl;
std::cout << "Temps dans phase: " << stats.time_in_current << "s" << std::endl;
std::cout << "Transitions: " << stats.total_transitions << std::endl;

// Durées par phase
auto duration_stats = stats.compute_duration_stats();
for (const auto& [phase, ds] : duration_stats) {
    std::cout << to_string(phase) << ": "
              << "mean=" << ds.mean << "s, "
              << "std=" << ds.std_dev << "s, "
              << "count=" << ds.count << std::endl;
}

// Historique des transitions
for (const auto& t : stats.transition_history) {
    std::cout << to_string(t.from_phase) << " → " 
              << to_string(t.to_phase) << " ("
              << t.duration_previous << "s)" << std::endl;
}
```

## 🐛 Debugging

### Activer les logs détaillés

```cpp
// Dans phase_detector.cpp, décommenter:
#define DEBUG_PHASE_DETECTOR

// Puis recompiler
```

### Afficher l'état en continu

```cpp
while (running) {
    detector.detect_phase(emotions);
    detector.display_status(emotions);
    std::this_thread::sleep_for(std::chrono::seconds(5));
}
```

## 📝 Notes importantes

1. **Thread-safety** : Le détecteur est thread-safe grâce à `std::mutex`
2. **Performance** : O(1) pour la détection, pas d'allocation dynamique
3. **Mémoire** : Historique des transitions limité (optionnellement configurable)
4. **Neo4j** : Intégration à faire selon votre driver (py2neo, neo4j-cpp, etc.)

## 🆘 Problèmes courants

### Oscillations rapides
```cpp
detector.set_hysteresis_margin(0.20);
detector.set_min_phase_duration(45.0);
```

### Phase ne change jamais
```cpp
// Vérifier les coefficients
auto scores = detector.compute_phase_scores(emotions);
// Vérifier la durée minimale
auto time_in_phase = detector.get_time_in_current_phase();
```

### Fuites mémoire
```cpp
// Vérifier avec valgrind
valgrind --leak-check=full ./mcee_phase_monitor
```

## 📚 Références

- Documentation MCEE : `MCEE_dev_summary.md`
- Système de phases Python : `mcee_phases_system.md`
- Formules mathématiques : `MCEE_dev_summary.md` section 2

## 📄 Licence

Projet MCEE - Anthropic

---

**Développé avec C++20 moderne** 🚀
