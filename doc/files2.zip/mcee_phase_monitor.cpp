// mcee_phase_monitor.cpp
// Moniteur MCEE avec détection automatique des phases émotionnelles

#include "phase_detector.hpp"
#include <SimpleAmqpClient/SimpleAmqpClient.h>
#include <nlohmann/json.hpp>
#include <iostream>
#include <iomanip>
#include <csignal>
#include <atomic>

using json = nlohmann::json;
using namespace mcee;

// =============================================================================
// CONFIGURATION
// =============================================================================

struct RabbitMQConfig {
    std::string host = "localhost";
    int port = 5672;
    std::string user = "virtus";
    std::string password = "virtus@83";
    std::string exchange = "mcee.emotional.input";
    std::string routing_key = "emotions.predictions";
};

// Variable globale pour l'arrêt propre
std::atomic<bool> running{true};

void signal_handler(int signal) {
    std::cout << "\n\n⛔ Signal reçu, arrêt en cours..." << std::endl;
    running = false;
}

// =============================================================================
// MONITEUR MCEE
// =============================================================================

class MCEEPhaseMonitor {
public:
    MCEEPhaseMonitor(const RabbitMQConfig& config)
        : config_(config)
        , phase_detector_(0.15, 30.0)  // hysteresis=0.15, min_duration=30s
        , message_count_(0)
    {}
    
    void start() {
        std::cout << "=" << std::string(70, '=') << std::endl;
        std::cout << "🧠 MCEE PHASE MONITOR" << std::endl;
        std::cout << "=" << std::string(70, '=') << std::endl;
        std::cout << "   Détection automatique des phases émotionnelles" << std::endl;
        std::cout << "   Modulation dynamique des coefficients MCEE" << std::endl;
        std::cout << "   Analyse en temps réel du profil émotionnel" << std::endl;
        std::cout << "=" << std::string(70, '=') << std::endl;
        std::cout << "\n⏳ En attente de prédictions... (Ctrl+C pour arrêter)\n" << std::endl;
        
        try {
            setup_rabbitmq();
            consume_messages();
        } catch (const std::exception& e) {
            std::cerr << "❌ Erreur: " << e.what() << std::endl;
        }
        
        display_final_summary();
    }
    
private:
    RabbitMQConfig config_;
    PhaseDetector phase_detector_;
    AmqpClient::Channel::ptr_t channel_;
    size_t message_count_;
    
    void setup_rabbitmq() {
        AmqpClient::Channel::OpenOpts opts;
        opts.host = config_.host;
        opts.port = config_.port;
        opts.auth = AmqpClient::Channel::OpenOpts::BasicAuth{config_.user, config_.password};
        
        channel_ = AmqpClient::Channel::Open(opts);
        
        // Déclarer l'exchange
        channel_->DeclareExchange(
            config_.exchange,
            AmqpClient::Channel::EXCHANGE_TYPE_TOPIC,
            false,  // passive
            true,   // durable
            false   // auto_delete
        );
        
        // Queue temporaire
        std::string queue_name = channel_->DeclareQueue(
            "",     // nom auto-généré
            false,  // passive
            false,  // durable
            true,   // exclusive
            false   // auto_delete
        );
        
        // Binding
        channel_->BindQueue(queue_name, config_.exchange, config_.routing_key);
        
        consumer_tag_ = channel_->BasicConsume(queue_name, "", true, false, false, 1);
        
        std::cout << "✅ Connecté à RabbitMQ" << std::endl;
        std::cout << "   Queue: " << queue_name << std::endl;
        std::cout << "   Exchange: " << config_.exchange << std::endl;
        std::cout << "   Routing Key: " << config_.routing_key << "\n" << std::endl;
    }
    
    void consume_messages() {
        while (running) {
            AmqpClient::Envelope::ptr_t envelope;
            bool received = channel_->BasicConsumeMessage(consumer_tag_, envelope, 1000);
            
            if (!received || !envelope) {
                continue;
            }
            
            try {
                process_message(envelope);
            } catch (const std::exception& e) {
                std::cerr << "❌ Erreur traitement: " << e.what() << std::endl;
            }
        }
    }
    
    void process_message(const AmqpClient::Envelope::ptr_t& envelope) {
        // Décoder le JSON
        std::string msg_str(envelope->Message()->Body().begin(), 
                           envelope->Message()->Body().end());
        
        json emotions_json = json::parse(msg_str);
        
        // Convertir en EmotionMap
        EmotionMap emotions;
        for (const auto& [name, value] : emotions_json.items()) {
            emotions[name] = value.get<double>();
        }
        
        message_count_++;
        
        std::cout << "\n" << std::string(70, '#') << std::endl;
        std::cout << "MESSAGE #" << message_count_ << " - " 
                  << get_current_time_string() << std::endl;
        std::cout << std::string(70, '#') << std::endl;
        
        // 1. Détection de phase
        Phase previous_phase = phase_detector_.get_current_phase();
        Phase current_phase = phase_detector_.detect_phase(emotions);
        
        // 2. Afficher si changement
        if (current_phase != previous_phase) {
            std::cout << "\n🔔 CHANGEMENT DE PHASE DÉTECTÉ !" << std::endl;
        }
        
        // 3. Afficher le statut
        phase_detector_.display_status(emotions);
        
        // 4. Analyse émotionnelle
        display_analysis(emotions);
        
        // 5. Recommandations
        display_recommendations(current_phase);
        
        // 6. Stats périodiques
        if (message_count_ % 10 == 0) {
            display_statistics();
        }
        
        // Acquitter le message
        channel_->BasicAck(envelope);
    }
    
    void display_analysis(const EmotionMap& emotions) const {
        auto profile = phase_detector_.analyze_emotional_profile(emotions);
        
        std::cout << "📈 ANALYSE DU PROFIL:" << std::endl;
        std::cout << std::string(70, '─') << std::endl;
        
        // Valence
        std::string valence_label = profile.valence > 0 ? "POSITIF" : "NÉGATIF";
        std::string valence_emoji = profile.valence > 0 ? "😊" : "😔";
        std::cout << "   Valence : " << std::showpos << std::fixed << std::setprecision(3) 
                  << profile.valence << std::noshowpos << " " << valence_emoji 
                  << " (" << valence_label << ")" << std::endl;
        
        // Arousal
        std::string arousal_label = profile.arousal > 0.6 ? "ÉLEVÉ" : 
                                   profile.arousal > 0.3 ? "MODÉRÉ" : "BAS";
        std::cout << "   Arousal : " << std::fixed << std::setprecision(3) 
                  << profile.arousal << " (" << arousal_label << ")" << std::endl;
        
        // Dominance
        std::string control_label = profile.dominance > 0 ? "BON CONTRÔLE" : "PERTE DE CONTRÔLE";
        std::string control_emoji = profile.dominance > 0 ? "✅" : "⚠️";
        std::cout << "   Contrôle: " << std::showpos << std::fixed << std::setprecision(3) 
                  << profile.dominance << std::noshowpos << " " << control_emoji 
                  << " (" << control_label << ")" << std::endl;
        
        std::cout << "\n   Émotion dominante: " << profile.max_emotion 
                  << " (" << std::fixed << std::setprecision(3) << profile.max_value << ")" 
                  << std::endl;
        
        std::cout << std::string(70, '─') << "\n" << std::endl;
    }
    
    void display_recommendations(Phase phase) const {
        std::cout << "💡 RECOMMANDATIONS SYSTÈME:" << std::endl;
        std::cout << std::string(70, '─') << std::endl;
        
        switch (phase) {
            case Phase::PEUR:
                std::cout << "   🚨 ÉTAT CRITIQUE - AMYGHALEON ACTIF" << std::endl;
                std::cout << "   → Priorité: SÉCURITÉ IMMÉDIATE" << std::endl;
                std::cout << "   → Actions: FUITE / BLOCAGE / ÉVITEMENT" << std::endl;
                std::cout << "   → Souvenirs traumatiques activés" << std::endl;
                std::cout << "   → Apprentissage rationnel désactivé" << std::endl;
                std::cout << "   ⚠️  Risque de création de trauma" << std::endl;
                break;
                
            case Phase::ANXIETE:
                std::cout << "   ⚠️  État de vigilance élevée" << std::endl;
                std::cout << "   → Hypervigilance aux menaces potentielles" << std::endl;
                std::cout << "   → Biais négatif dans l'interprétation" << std::endl;
                std::cout << "   → Activation souvenirs anxiogènes" << std::endl;
                break;
                
            case Phase::TRISTESSE:
                std::cout << "   😢 État mélancolique" << std::endl;
                std::cout << "   → Rumination sur le passé probable" << std::endl;
                std::cout << "   → Énergie et motivation basses" << std::endl;
                std::cout << "   → Introspection possible (positif)" << std::endl;
                break;
                
            case Phase::JOIE:
                std::cout << "   🎉 État euphorique" << std::endl;
                std::cout << "   → Renforcement souvenirs positifs actif" << std::endl;
                std::cout << "   → Apprentissage accéléré" << std::endl;
                std::cout << "   ⚠️  Attention: sous-évaluation des risques" << std::endl;
                break;
                
            case Phase::EXPLORATION:
                std::cout << "   🔍 Mode exploration actif" << std::endl;
                std::cout << "   → Apprentissage MAXIMAL" << std::endl;
                std::cout << "   → Attention très focalisée" << std::endl;
                std::cout << "   → État optimal pour apprentissage" << std::endl;
                break;
                
            case Phase::SERENITE:
                std::cout << "   🌅 État d'équilibre" << std::endl;
                std::cout << "   → Conditions optimales pour réflexion" << std::endl;
                std::cout << "   → Apprentissage équilibré" << std::endl;
                break;
                
            case Phase::DEGOUT:
                std::cout << "   🤢 Réaction d'évitement" << std::endl;
                std::cout << "   → Apprentissage d'évitement activé" << std::endl;
                std::cout << "   ⚠️  Risque de généralisation excessive" << std::endl;
                break;
                
            case Phase::CONFUSION:
                std::cout << "   😕 État d'incertitude" << std::endl;
                std::cout << "   → Recherche active d'information" << std::endl;
                std::cout << "   → Sollicitation mémoire intense" << std::endl;
                break;
        }
        
        std::cout << std::string(70, '─') << "\n" << std::endl;
    }
    
    void display_statistics() const {
        auto stats = phase_detector_.get_statistics();
        
        std::cout << "\n📊 STATISTIQUES GLOBALES (après " << message_count_ << " messages)" << std::endl;
        std::cout << std::string(70, '=') << std::endl;
        std::cout << "   Phase actuelle: " << to_string(stats.current_phase) << std::endl;
        std::cout << "   Temps dans phase: " << std::fixed << std::setprecision(1) 
                  << stats.time_in_current << "s" << std::endl;
        std::cout << "   Nombre de transitions: " << stats.total_transitions << std::endl;
        
        // Calculer stats de durée
        auto duration_stats = stats.compute_duration_stats();
        if (!duration_stats.empty()) {
            std::cout << "\n   Durées moyennes par phase:" << std::endl;
            for (const auto& [phase, ds] : duration_stats) {
                std::cout << "      " << std::left << std::setw(12) << to_string(phase) 
                          << ": " << std::fixed << std::setprecision(1) << ds.mean << "s "
                          << "(σ=" << ds.std_dev << ", n=" << ds.count << ")" << std::endl;
            }
        }
        
        std::cout << std::string(70, '=') << "\n" << std::endl;
    }
    
    void display_final_summary() const {
        std::cout << "\n" << std::string(70, '=') << std::endl;
        std::cout << "📋 RÉSUMÉ DE LA SESSION" << std::endl;
        std::cout << std::string(70, '=') << std::endl;
        
        auto stats = phase_detector_.get_statistics();
        
        std::cout << "\n   Messages traités: " << message_count_ << std::endl;
        std::cout << "   Transitions totales: " << stats.total_transitions << std::endl;
        std::cout << "   Phase finale: " << to_string(stats.current_phase) << std::endl;
        
        // Historique des transitions
        auto recent = phase_detector_.get_recent_transitions(10);
        if (!recent.empty()) {
            std::cout << "\n   Historique des transitions:" << std::endl;
            for (size_t i = 0; i < recent.size(); ++i) {
                const auto& t = recent[i];
                std::cout << "      " << (i+1) << ". " 
                          << to_string(t.from_phase) << " → " << to_string(t.to_phase)
                          << " - " << t.reason << std::endl;
            }
        }
        
        std::cout << "\n" << std::string(70, '=') << "\n" << std::endl;
    }
    
    static std::string get_current_time_string() {
        auto now = std::chrono::system_clock::now();
        auto time_t = std::chrono::system_clock::to_time_t(now);
        std::tm tm = *std::localtime(&time_t);
        
        std::ostringstream oss;
        oss << std::put_time(&tm, "%H:%M:%S");
        return oss.str();
    }
    
    std::string consumer_tag_;
};

// =============================================================================
// IMPLÉMENTATION DE PhaseStatistics::compute_duration_stats
// =============================================================================

namespace mcee {

std::unordered_map<Phase, PhaseStatistics::PhaseDurationStats> 
PhaseStatistics::compute_duration_stats() const {
    std::unordered_map<Phase, PhaseDurationStats> stats;
    
    for (const auto& [phase, durations] : phase_durations) {
        if (durations.empty()) continue;
        
        PhaseDurationStats ds;
        ds.count = durations.size();
        
        // Mean
        ds.mean = std::accumulate(durations.begin(), durations.end(), 0.0) / durations.size();
        
        // Min/Max
        ds.min = *std::min_element(durations.begin(), durations.end());
        ds.max = *std::max_element(durations.begin(), durations.end());
        
        // Std dev
        double sum_sq = 0.0;
        for (double d : durations) {
            double diff = d - ds.mean;
            sum_sq += diff * diff;
        }
        ds.std_dev = std::sqrt(sum_sq / durations.size());
        
        stats[phase] = ds;
    }
    
    return stats;
}

} // namespace mcee

// =============================================================================
// MAIN
// =============================================================================

int main() {
    // Installer le handler de signal
    std::signal(SIGINT, signal_handler);
    std::signal(SIGTERM, signal_handler);
    
    // Configuration
    RabbitMQConfig config;
    
    // Créer et démarrer le moniteur
    MCEEPhaseMonitor monitor(config);
    monitor.start();
    
    return 0;
}
