#pragma once

#include <string>
#include <array>
#include <unordered_map>
#include <chrono>
#include <vector>
#include <functional>
#include <optional>

namespace mcee {

// =============================================================================
// TYPES ET CONSTANTES
// =============================================================================

constexpr size_t NUM_EMOTIONS = 24;
constexpr size_t NUM_DIMENSIONS = 14;

using EmotionVector = std::array<double, NUM_EMOTIONS>;
using DimensionVector = std::array<double, NUM_DIMENSIONS>;
using EmotionMap = std::unordered_map<std::string, double>;
using TimePoint = std::chrono::system_clock::time_point;
using Duration = std::chrono::duration<double>;

// =============================================================================
// ÉNUMÉRATION DES PHASES
// =============================================================================

enum class Phase {
    SERENITE,
    JOIE,
    EXPLORATION,
    ANXIETE,
    PEUR,
    TRISTESSE,
    DEGOUT,
    CONFUSION
};

// Conversion Phase <-> string
inline std::string to_string(Phase phase) {
    switch (phase) {
        case Phase::SERENITE:    return "SERENITE";
        case Phase::JOIE:        return "JOIE";
        case Phase::EXPLORATION: return "EXPLORATION";
        case Phase::ANXIETE:     return "ANXIETE";
        case Phase::PEUR:        return "PEUR";
        case Phase::TRISTESSE:   return "TRISTESSE";
        case Phase::DEGOUT:      return "DEGOUT";
        case Phase::CONFUSION:   return "CONFUSION";
        default:                 return "UNKNOWN";
    }
}

inline Phase phase_from_string(const std::string& str) {
    if (str == "SERENITE")    return Phase::SERENITE;
    if (str == "JOIE")        return Phase::JOIE;
    if (str == "EXPLORATION") return Phase::EXPLORATION;
    if (str == "ANXIETE")     return Phase::ANXIETE;
    if (str == "PEUR")        return Phase::PEUR;
    if (str == "TRISTESSE")   return Phase::TRISTESSE;
    if (str == "DEGOUT")      return Phase::DEGOUT;
    if (str == "CONFUSION")   return Phase::CONFUSION;
    return Phase::SERENITE;
}

// =============================================================================
// CONFIGURATION D'UNE PHASE
// =============================================================================

struct PhaseConfig {
    // Coefficients MCEE
    double alpha;  // Feedback externe
    double beta;   // Feedback interne
    double gamma;  // Décroissance temporelle
    double delta;  // Influence des souvenirs
    double theta;  // Coefficient de sagesse
    
    // Seuils de décision
    double amyghaleon_threshold;
    double memory_consolidation;
    double attention_focus;
    double learning_rate;
    
    // Métadonnées
    int priority;
    std::string description;
};

// =============================================================================
// TRANSITION DE PHASE
// =============================================================================

struct PhaseTransition {
    Phase from_phase;
    Phase to_phase;
    TimePoint timestamp;
    double duration_previous;  // En secondes
    EmotionMap trigger_emotions;
    std::string reason;
    
    PhaseTransition(Phase from, Phase to, TimePoint time, double dur, 
                   const EmotionMap& emotions, const std::string& rsn)
        : from_phase(from), to_phase(to), timestamp(time), 
          duration_previous(dur), trigger_emotions(emotions), reason(rsn) {}
};

// =============================================================================
// ANALYSE DU PROFIL ÉMOTIONNEL
// =============================================================================

struct EmotionalProfile {
    double valence;      // Positif/Négatif [-1, +1]
    double arousal;      // Activation [0, 1]
    double dominance;    // Contrôle perçu [-2, +2]
    double variance;     // Variance des émotions
    std::string max_emotion;
    double max_value;
    double positive_mean;
    double negative_mean;
};

// =============================================================================
// NOMS DES ÉMOTIONS (ordre du modèle)
// =============================================================================

inline const std::array<std::string, NUM_EMOTIONS> EMOTION_NAMES = {
    "Admiration", "Adoration", "Appréciation esthétique", "Amusement",
    "Anxiété", "Émerveillement", "Gêne", "Ennui",
    "Calme", "Confusion", "Dégoût", "Douleur empathique",
    "Fascination", "Excitation", "Peur", "Horreur",
    "Intérêt", "Joie", "Nostalgie", "Soulagement",
    "Tristesse", "Satisfaction", "Sympathie", "Triomphe"
};

// =============================================================================
// ÉMOTIONS PAR CATÉGORIE
// =============================================================================

inline const std::vector<std::string> POSITIVE_EMOTIONS = {
    "Admiration", "Adoration", "Amusement", "Émerveillement", 
    "Calme", "Fascination", "Excitation", "Intérêt", 
    "Joie", "Soulagement", "Satisfaction", "Triomphe"
};

inline const std::vector<std::string> NEGATIVE_EMOTIONS = {
    "Peur", "Horreur", "Anxiété", "Tristesse", "Dégoût", 
    "Douleur empathique", "Gêne", "Confusion", "Ennui"
};

inline const std::vector<std::string> HIGH_AROUSAL_EMOTIONS = {
    "Peur", "Horreur", "Excitation", "Anxiété", "Joie"
};

// =============================================================================
// STATISTIQUES DE PHASE
// =============================================================================

struct PhaseStatistics {
    Phase current_phase;
    double time_in_current;
    int total_transitions;
    std::unordered_map<Phase, std::vector<double>> phase_durations;
    std::vector<PhaseTransition> transition_history;
    
    struct PhaseDurationStats {
        double mean;
        double std_dev;
        double min;
        double max;
        size_t count;
    };
    
    std::unordered_map<Phase, PhaseDurationStats> compute_duration_stats() const;
};

} // namespace mcee
