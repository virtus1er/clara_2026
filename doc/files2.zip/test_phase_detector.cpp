// test_phase_detector.cpp
// Programme de test pour le détecteur de phases émotionnelles

#include "phase_detector.hpp"
#include <iostream>
#include <iomanip>

using namespace mcee;

// =============================================================================
// PROFILS DE TEST
// =============================================================================

EmotionMap create_peur_profile() {
    return {
        {"Admiration", 0.000}, {"Adoration", 0.000}, {"Appréciation esthétique", 0.000},
        {"Amusement", 0.000}, {"Anxiété", 0.659}, {"Émerveillement", 0.000},
        {"Gêne", 0.000}, {"Ennui", 0.000}, {"Calme", 0.000},
        {"Confusion", 0.157}, {"Dégoût", 0.428}, {"Douleur empathique", 0.330},
        {"Fascination", 0.000}, {"Excitation", 0.066}, {"Peur", 0.927},
        {"Horreur", 0.838}, {"Intérêt", 0.000}, {"Joie", 0.000},
        {"Nostalgie", 0.000}, {"Soulagement", 0.177}, {"Tristesse", 0.624},
        {"Satisfaction", 0.000}, {"Sympathie", 0.320}, {"Triomphe", 0.000}
    };
}

EmotionMap create_joie_profile() {
    return {
        {"Admiration", 0.520}, {"Adoration", 0.380}, {"Appréciation esthétique", 0.450},
        {"Amusement", 0.720}, {"Anxiété", 0.050}, {"Émerveillement", 0.380},
        {"Gêne", 0.020}, {"Ennui", 0.010}, {"Calme", 0.340},
        {"Confusion", 0.030}, {"Dégoût", 0.015}, {"Douleur empathique", 0.040},
        {"Fascination", 0.290}, {"Excitation", 0.850}, {"Peur", 0.020},
        {"Horreur", 0.010}, {"Intérêt", 0.420}, {"Joie", 0.920},
        {"Nostalgie", 0.180}, {"Soulagement", 0.340}, {"Tristesse", 0.030},
        {"Satisfaction", 0.780}, {"Sympathie", 0.320}, {"Triomphe", 0.450}
    };
}

EmotionMap create_serenite_profile() {
    return {
        {"Admiration", 0.280}, {"Adoration", 0.180}, {"Appréciation esthétique", 0.320},
        {"Amusement", 0.220}, {"Anxiété", 0.080}, {"Émerveillement", 0.180},
        {"Gêne", 0.030}, {"Ennui", 0.040}, {"Calme", 0.820},
        {"Confusion", 0.050}, {"Dégoût", 0.020}, {"Douleur empathique", 0.040},
        {"Fascination", 0.180}, {"Excitation", 0.120}, {"Peur", 0.030},
        {"Horreur", 0.015}, {"Intérêt", 0.320}, {"Joie", 0.380},
        {"Nostalgie", 0.220}, {"Soulagement", 0.420}, {"Tristesse", 0.060},
        {"Satisfaction", 0.720}, {"Sympathie", 0.280}, {"Triomphe", 0.180}
    };
}

EmotionMap create_exploration_profile() {
    return {
        {"Admiration", 0.680}, {"Adoration", 0.280}, {"Appréciation esthétique", 0.520},
        {"Amusement", 0.320}, {"Anxiété", 0.180}, {"Émerveillement", 0.580},
        {"Gêne", 0.040}, {"Ennui", 0.020}, {"Calme", 0.280},
        {"Confusion", 0.120}, {"Dégoût", 0.025}, {"Douleur empathique", 0.050},
        {"Fascination", 0.850}, {"Excitation", 0.520}, {"Peur", 0.080},
        {"Horreur", 0.030}, {"Intérêt", 0.920}, {"Joie", 0.480},
        {"Nostalgie", 0.120}, {"Soulagement", 0.180}, {"Tristesse", 0.060},
        {"Satisfaction", 0.420}, {"Sympathie", 0.220}, {"Triomphe", 0.280}
    };
}

// =============================================================================
// FONCTIONS D'AFFICHAGE
// =============================================================================

void print_header(const std::string& title) {
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << title << std::endl;
    std::cout << std::string(70, '=') << std::endl;
}

void test_profile(PhaseDetector& detector, const std::string& name, 
                 const EmotionMap& emotions) {
    print_header("TEST: " + name);
    
    // Détection
    Phase detected = detector.detect_phase(emotions);
    
    // Affichage complet
    detector.display_status(emotions);
    
    // Analyse
    auto profile = detector.analyze_emotional_profile(emotions);
    
    std::cout << "📈 ANALYSE DU PROFIL:" << std::endl;
    std::cout << std::string(70, '─') << std::endl;
    std::cout << "   Valence   : " << std::showpos << std::fixed << std::setprecision(3) 
              << profile.valence << std::noshowpos << std::endl;
    std::cout << "   Arousal   : " << std::fixed << std::setprecision(3) 
              << profile.arousal << std::endl;
    std::cout << "   Dominance : " << std::showpos << std::fixed << std::setprecision(3) 
              << profile.dominance << std::noshowpos << std::endl;
    std::cout << "   Variance  : " << std::fixed << std::setprecision(3) 
              << profile.variance << std::endl;
    std::cout << std::string(70, '─') << std::endl;
}

void test_transitions(PhaseDetector& detector) {
    print_header("TEST DES TRANSITIONS");
    
    std::cout << "Simulation d'une séquence émotionnelle...\n" << std::endl;
    
    // Séquence: Sérénité → Exploration → Joie → Peur
    
    std::cout << "1. État initial (Sérénité)" << std::endl;
    auto serenite = create_serenite_profile();
    detector.detect_phase(serenite);
    std::cout << "   Phase: " << to_string(detector.get_current_phase()) << "\n" << std::endl;
    
    // Attendre un peu
    std::this_thread::sleep_for(std::chrono::seconds(2));
    
    std::cout << "2. Découverte intéressante (Exploration)" << std::endl;
    auto exploration = create_exploration_profile();
    detector.detect_phase(exploration);
    std::cout << "   Phase: " << to_string(detector.get_current_phase()) << "\n" << std::endl;
    
    std::this_thread::sleep_for(std::chrono::seconds(2));
    
    std::cout << "3. Succès de l'exploration (Joie)" << std::endl;
    auto joie = create_joie_profile();
    detector.detect_phase(joie);
    std::cout << "   Phase: " << to_string(detector.get_current_phase()) << "\n" << std::endl;
    
    std::this_thread::sleep_for(std::chrono::seconds(2));
    
    std::cout << "4. Menace soudaine (Peur) ⚠️" << std::endl;
    auto peur = create_peur_profile();
    detector.detect_phase(peur);
    std::cout << "   Phase: " << to_string(detector.get_current_phase()) << "\n" << std::endl;
    
    // Afficher l'historique
    std::cout << "\n📜 HISTORIQUE DES TRANSITIONS:" << std::endl;
    std::cout << std::string(70, '─') << std::endl;
    
    auto transitions = detector.get_recent_transitions(10);
    for (size_t i = 0; i < transitions.size(); ++i) {
        const auto& t = transitions[i];
        std::cout << "   " << (i+1) << ". " 
                  << to_string(t.from_phase) << " → " << to_string(t.to_phase)
                  << " (" << std::fixed << std::setprecision(1) << t.duration_previous << "s)"
                  << " - " << t.reason << std::endl;
    }
    
    std::cout << std::string(70, '─') << std::endl;
}

void test_hysteresis(PhaseDetector& detector) {
    print_header("TEST DE L'HYSTERESIS");
    
    std::cout << "L'hysteresis empêche les oscillations rapides entre phases.\n" << std::endl;
    
    // Créer un profil ambigu (entre Anxiété et Peur)
    EmotionMap ambigu = {
        {"Admiration", 0.000}, {"Adoration", 0.000}, {"Appréciation esthétique", 0.000},
        {"Amusement", 0.000}, {"Anxiété", 0.650}, {"Émerveillement", 0.000},
        {"Gêne", 0.000}, {"Ennui", 0.000}, {"Calme", 0.000},
        {"Confusion", 0.220}, {"Dégoût", 0.180}, {"Douleur empathique", 0.150},
        {"Fascination", 0.000}, {"Excitation", 0.050}, {"Peur", 0.750},  // Limite
        {"Horreur", 0.420}, {"Intérêt", 0.000}, {"Joie", 0.000},
        {"Nostalgie", 0.000}, {"Soulagement", 0.080}, {"Tristesse", 0.380},
        {"Satisfaction", 0.000}, {"Sympathie", 0.150}, {"Triomphe", 0.000}
    };
    
    std::cout << "État initial: Sérénité" << std::endl;
    detector.detect_phase(create_serenite_profile());
    std::cout << "   Phase: " << to_string(detector.get_current_phase()) << "\n" << std::endl;
    
    std::this_thread::sleep_for(std::chrono::seconds(1));
    
    std::cout << "État ambigu (Peur=0.75, Anxiété=0.65)" << std::endl;
    std::cout << "Tentative 1..." << std::endl;
    detector.detect_phase(ambigu);
    std::cout << "   Phase: " << to_string(detector.get_current_phase()) 
              << " (pas de changement si durée minimale non atteinte)\n" << std::endl;
    
    std::this_thread::sleep_for(std::chrono::seconds(31));  // Dépasser durée minimale
    
    std::cout << "Tentative 2 (après durée minimale)..." << std::endl;
    detector.detect_phase(ambigu);
    std::cout << "   Phase: " << to_string(detector.get_current_phase()) << "\n" << std::endl;
}

// =============================================================================
// MAIN
// =============================================================================

int main() {
    std::cout << "╔" << std::string(68, '═') << "╗" << std::endl;
    std::cout << "║" << std::string(15, ' ') << "TEST DU DÉTECTEUR DE PHASES" 
              << std::string(26, ' ') << "║" << std::endl;
    std::cout << "║" << std::string(23, ' ') << "MCEE C++20" 
              << std::string(36, ' ') << "║" << std::endl;
    std::cout << "╚" << std::string(68, '═') << "╝" << std::endl;
    
    // Créer le détecteur
    PhaseDetector detector(0.15, 30.0);
    
    // Tests individuels
    std::cout << "\n📝 TESTS DES PROFILS ÉMOTIONNELS\n" << std::endl;
    
    test_profile(detector, "Profil PEUR (exemple utilisateur)", create_peur_profile());
    std::this_thread::sleep_for(std::chrono::seconds(2));
    
    test_profile(detector, "Profil JOIE", create_joie_profile());
    std::this_thread::sleep_for(std::chrono::seconds(2));
    
    test_profile(detector, "Profil SÉRÉNITÉ", create_serenite_profile());
    std::this_thread::sleep_for(std::chrono::seconds(2));
    
    test_profile(detector, "Profil EXPLORATION", create_exploration_profile());
    
    // Test des transitions
    PhaseDetector detector2(0.15, 2.0);  // Durée minimale réduite pour le test
    test_transitions(detector2);
    
    // Test de l'hysteresis
    PhaseDetector detector3(0.15, 30.0);
    test_hysteresis(detector3);
    
    // Statistiques finales
    print_header("STATISTIQUES FINALES");
    auto stats = detector2.get_statistics();
    std::cout << "   Messages traités: " << stats.transition_history.size() + 1 << std::endl;
    std::cout << "   Transitions totales: " << stats.total_transitions << std::endl;
    std::cout << "   Phase finale: " << to_string(stats.current_phase) << std::endl;
    
    std::cout << "\n✅ Tous les tests terminés avec succès !\n" << std::endl;
    
    return 0;
}
