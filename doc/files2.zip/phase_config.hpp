#pragma once

#include "phase_types.hpp"
#include <unordered_map>

namespace mcee {

// =============================================================================
// CONFIGURATIONS DES PHASES
// =============================================================================

inline const std::unordered_map<Phase, PhaseConfig> PHASE_CONFIGS = {
    {Phase::SERENITE, {
        .alpha = 0.25,
        .beta = 0.15,
        .gamma = 0.12,
        .delta = 0.30,
        .theta = 0.10,
        .amyghaleon_threshold = 0.85,
        .memory_consolidation = 0.4,
        .attention_focus = 0.5,
        .learning_rate = 1.0,
        .priority = 1,
        .description = "État d'équilibre - Apprentissage optimal"
    }},
    
    {Phase::JOIE, {
        .alpha = 0.40,
        .beta = 0.25,
        .gamma = 0.08,
        .delta = 0.35,
        .theta = 0.05,
        .amyghaleon_threshold = 0.95,
        .memory_consolidation = 0.5,
        .attention_focus = 0.3,
        .learning_rate = 1.3,
        .priority = 2,
        .description = "État euphorique - Renforcement positif"
    }},
    
    {Phase::EXPLORATION, {
        .alpha = 0.35,
        .beta = 0.10,
        .gamma = 0.10,
        .delta = 0.25,
        .theta = 0.15,
        .amyghaleon_threshold = 0.80,
        .memory_consolidation = 0.6,
        .attention_focus = 0.8,
        .learning_rate = 1.5,
        .priority = 2,
        .description = "Mode exploration - Apprentissage maximal"
    }},
    
    {Phase::ANXIETE, {
        .alpha = 0.40,
        .beta = 0.30,
        .gamma = 0.06,
        .delta = 0.45,
        .theta = 0.08,
        .amyghaleon_threshold = 0.70,
        .memory_consolidation = 0.4,
        .attention_focus = 0.6,
        .learning_rate = 0.8,
        .priority = 3,
        .description = "État de vigilance - Hypervigilance aux menaces"
    }},
    
    {Phase::PEUR, {
        .alpha = 0.60,
        .beta = 0.45,
        .gamma = 0.02,
        .delta = 0.70,
        .theta = 0.02,
        .amyghaleon_threshold = 0.50,
        .memory_consolidation = 0.8,
        .attention_focus = 0.95,
        .learning_rate = 0.3,
        .priority = 5,  // PRIORITÉ MAXIMALE
        .description = "URGENCE - Amyghaleon actif - Traumas dominants"
    }},
    
    {Phase::TRISTESSE, {
        .alpha = 0.20,
        .beta = 0.40,
        .gamma = 0.05,
        .delta = 0.55,
        .theta = 0.12,
        .amyghaleon_threshold = 0.90,
        .memory_consolidation = 0.5,
        .attention_focus = 0.4,
        .learning_rate = 0.6,
        .priority = 3,
        .description = "État mélancolique - Rumination sur le passé"
    }},
    
    {Phase::DEGOUT, {
        .alpha = 0.50,
        .beta = 0.25,
        .gamma = 0.08,
        .delta = 0.40,
        .theta = 0.08,
        .amyghaleon_threshold = 0.75,
        .memory_consolidation = 0.6,
        .attention_focus = 0.7,
        .learning_rate = 0.9,
        .priority = 4,
        .description = "Réaction d'évitement - Associations négatives"
    }},
    
    {Phase::CONFUSION, {
        .alpha = 0.35,
        .beta = 0.30,
        .gamma = 0.15,
        .delta = 0.50,
        .theta = 0.15,
        .amyghaleon_threshold = 0.80,
        .memory_consolidation = 0.3,
        .attention_focus = 0.5,
        .learning_rate = 0.7,
        .priority = 2,
        .description = "État d'incertitude - Recherche active d'information"
    }}
};

// =============================================================================
// CRITÈRES DE DÉTECTION DES PHASES
// =============================================================================

// Type pour les fonctions de critère
using CriterionFunction = std::function<bool(const EmotionMap&)>;

struct PhaseCriterion {
    CriterionFunction func;
    int priority;
    std::vector<std::string> key_emotions;
};

// Fonctions utilitaires pour les critères
inline double max_negative(const EmotionMap& emotions) {
    double max_val = 0.0;
    for (const auto& emo : NEGATIVE_EMOTIONS) {
        auto it = emotions.find(emo);
        if (it != emotions.end() && it->second > max_val) {
            max_val = it->second;
        }
    }
    return max_val;
}

inline double compute_variance(const EmotionMap& emotions) {
    if (emotions.empty()) return 0.0;
    
    double sum = 0.0, sum_sq = 0.0;
    for (const auto& [name, value] : emotions) {
        sum += value;
        sum_sq += value * value;
    }
    
    double mean = sum / emotions.size();
    double variance = (sum_sq / emotions.size()) - (mean * mean);
    return variance;
}

inline double get_emotion(const EmotionMap& emotions, const std::string& name, double default_val = 0.0) {
    auto it = emotions.find(name);
    return (it != emotions.end()) ? it->second : default_val;
}

// Critères pour chaque phase
inline const std::unordered_map<Phase, PhaseCriterion> PHASE_CRITERIA = {
    {Phase::SERENITE, {
        .func = [](const EmotionMap& e) {
            return get_emotion(e, "Calme") > 0.5 &&
                   get_emotion(e, "Satisfaction") > 0.4 &&
                   max_negative(e) < 0.3;
        },
        .priority = 1,
        .key_emotions = {"Calme", "Satisfaction"}
    }},
    
    {Phase::JOIE, {
        .func = [](const EmotionMap& e) {
            return (get_emotion(e, "Joie") > 0.6 || get_emotion(e, "Excitation") > 0.6) &&
                   get_emotion(e, "Amusement") > 0.4;
        },
        .priority = 2,
        .key_emotions = {"Joie", "Excitation", "Amusement"}
    }},
    
    {Phase::EXPLORATION, {
        .func = [](const EmotionMap& e) {
            return (get_emotion(e, "Intérêt") > 0.6 || get_emotion(e, "Fascination") > 0.5) &&
                   get_emotion(e, "Anxiété") < 0.4;
        },
        .priority = 2,
        .key_emotions = {"Intérêt", "Fascination", "Admiration"}
    }},
    
    {Phase::ANXIETE, {
        .func = [](const EmotionMap& e) {
            double anxiete = get_emotion(e, "Anxiété");
            return anxiete > 0.5 && anxiete < 0.8 &&
                   get_emotion(e, "Peur") < 0.6;
        },
        .priority = 3,
        .key_emotions = {"Anxiété", "Peur", "Confusion"}
    }},
    
    {Phase::PEUR, {
        .func = [](const EmotionMap& e) {
            return get_emotion(e, "Peur") > 0.8 || get_emotion(e, "Horreur") > 0.7;
        },
        .priority = 5,  // PRIORITÉ MAXIMALE
        .key_emotions = {"Peur", "Horreur", "Anxiété"}
    }},
    
    {Phase::TRISTESSE, {
        .func = [](const EmotionMap& e) {
            return get_emotion(e, "Tristesse") > 0.6 &&
                   get_emotion(e, "Douleur empathique") > 0.4;
        },
        .priority = 3,
        .key_emotions = {"Tristesse", "Douleur empathique", "Nostalgie"}
    }},
    
    {Phase::DEGOUT, {
        .func = [](const EmotionMap& e) {
            return get_emotion(e, "Dégoût") > 0.6;
        },
        .priority = 4,
        .key_emotions = {"Dégoût", "Horreur"}
    }},
    
    {Phase::CONFUSION, {
        .func = [](const EmotionMap& e) {
            return get_emotion(e, "Confusion") > 0.6 || compute_variance(e) > 0.3;
        },
        .priority = 2,
        .key_emotions = {"Confusion"}
    }}
};

} // namespace mcee
