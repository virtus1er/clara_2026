#pragma once

#include "phase_types.hpp"
#include "phase_config.hpp"
#include <memory>
#include <mutex>
#include <optional>

namespace mcee {

// =============================================================================
// DÉTECTEUR DE PHASE ÉMOTIONNELLE
// =============================================================================

class PhaseDetector {
public:
    // Constructeur
    explicit PhaseDetector(
        double hysteresis_margin = 0.15,
        double min_phase_duration_seconds = 30.0
    );
    
    // Détection principale
    Phase detect_phase(const EmotionMap& emotions);
    
    // Accesseurs
    Phase get_current_phase() const { return current_phase_; }
    const PhaseConfig& get_phase_config() const;
    const PhaseConfig& get_phase_config(Phase phase) const;
    
    // Analyse
    EmotionalProfile analyze_emotional_profile(const EmotionMap& emotions) const;
    
    // Statistiques
    PhaseStatistics get_statistics() const;
    std::vector<PhaseTransition> get_recent_transitions(size_t n = 5) const;
    double get_time_in_current_phase() const;
    
    // Configuration
    void set_hysteresis_margin(double margin) { hysteresis_margin_ = margin; }
    void set_min_phase_duration(double seconds) { 
        min_phase_duration_ = std::chrono::duration<double>(seconds); 
    }
    
    // Affichage (pour debug)
    void display_status(const EmotionMap& emotions) const;
    std::string get_phase_info() const;
    
private:
    // État interne
    Phase current_phase_;
    TimePoint phase_start_time_;
    std::vector<PhaseTransition> transition_history_;
    std::unordered_map<Phase, std::vector<double>> phase_durations_;
    size_t total_transitions_;
    
    // Configuration
    double hysteresis_margin_;
    Duration min_phase_duration_;
    
    // Thread safety
    mutable std::mutex mutex_;
    
    // Méthodes privées
    std::unordered_map<Phase, double> compute_phase_scores(const EmotionMap& emotions) const;
    double compute_phase_intensity(const std::vector<std::string>& key_emotions, 
                                   const EmotionMap& emotions) const;
    bool is_emergency(Phase phase, double score, const EmotionMap& emotions) const;
    void transition_to(Phase new_phase, const EmotionMap& emotions, const std::string& reason);
    
    // Utilitaires
    static double mean(const std::vector<double>& values);
    static double std_dev(const std::vector<double>& values);
};

// =============================================================================
// FONCTIONS UTILITAIRES
// =============================================================================

// Conversion EmotionVector <-> EmotionMap
EmotionMap emotion_vector_to_map(const EmotionVector& vec);
EmotionVector emotion_map_to_vector(const EmotionMap& map);

// Analyse rapide
double compute_valence(const EmotionMap& emotions);
double compute_arousal(const EmotionMap& emotions);
double compute_dominance(const EmotionMap& emotions);

// Affichage
std::string format_emotion_bar(double value, size_t width = 20);
std::string format_duration(double seconds);

} // namespace mcee
