#include "phase_detector.hpp"
#include <algorithm>
#include <numeric>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <sstream>

namespace mcee {

// =============================================================================
// CONSTRUCTEUR
// =============================================================================

PhaseDetector::PhaseDetector(double hysteresis_margin, double min_phase_duration_seconds)
    : current_phase_(Phase::SERENITE)
    , phase_start_time_(std::chrono::system_clock::now())
    , total_transitions_(0)
    , hysteresis_margin_(hysteresis_margin)
    , min_phase_duration_(std::chrono::duration<double>(min_phase_duration_seconds))
{
    // Initialiser les durées pour chaque phase
    for (int i = 0; i <= static_cast<int>(Phase::CONFUSION); ++i) {
        phase_durations_[static_cast<Phase>(i)] = std::vector<double>();
    }
}

// =============================================================================
// DÉTECTION PRINCIPALE
// =============================================================================

Phase PhaseDetector::detect_phase(const EmotionMap& emotions) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    // 1. Calculer les scores de chaque phase
    auto phase_scores = compute_phase_scores(emotions);
    
    // 2. Trouver la phase avec le score maximal
    if (phase_scores.empty()) {
        return Phase::SERENITE;
    }
    
    auto best = std::max_element(phase_scores.begin(), phase_scores.end(),
        [](const auto& a, const auto& b) { return a.second < b.second; });
    
    Phase best_phase = best->first;
    double best_score = best->second;
    
    // 3. Vérifier les conditions d'urgence (court-circuit)
    if (is_emergency(best_phase, best_score, emotions)) {
        std::cout << "⚠️ URGENCE: Transition immédiate vers " << to_string(best_phase) << std::endl;
        transition_to(best_phase, emotions, "URGENCE");
        return best_phase;
    }
    
    // 4. Appliquer l'hysteresis (stabilité)
    double current_score = phase_scores.count(current_phase_) ? 
                          phase_scores[current_phase_] : 0.0;
    
    if (current_score > best_score - hysteresis_margin_) {
        // Rester dans la phase actuelle (stable)
        return current_phase_;
    }
    
    // 5. Vérifier la durée minimale
    auto time_in_phase = std::chrono::system_clock::now() - phase_start_time_;
    if (time_in_phase < min_phase_duration_) {
        // Trop tôt pour changer
        return current_phase_;
    }
    
    // 6. Effectuer la transition
    transition_to(best_phase, emotions, "SCORE_SUPERIEUR");
    return best_phase;
}

// =============================================================================
// CALCUL DES SCORES
// =============================================================================

std::unordered_map<Phase, double> PhaseDetector::compute_phase_scores(
    const EmotionMap& emotions) const {
    
    std::unordered_map<Phase, double> scores;
    
    for (const auto& [phase, criterion] : PHASE_CRITERIA) {
        try {
            // Vérifier si les critères sont remplis
            if (criterion.func(emotions)) {
                // Score = priorité + intensité moyenne des émotions clés
                double priority = static_cast<double>(criterion.priority);
                double intensity = compute_phase_intensity(criterion.key_emotions, emotions);
                scores[phase] = priority + intensity;
            }
        } catch (const std::exception& e) {
            std::cerr << "Erreur calcul score " << to_string(phase) << ": " << e.what() << std::endl;
            scores[phase] = 0.0;
        }
    }
    
    return scores;
}

double PhaseDetector::compute_phase_intensity(
    const std::vector<std::string>& key_emotions,
    const EmotionMap& emotions) const {
    
    if (key_emotions.empty()) return 0.0;
    
    double sum = 0.0;
    for (const auto& emo_name : key_emotions) {
        sum += get_emotion(emotions, emo_name, 0.0);
    }
    
    return sum / key_emotions.size();
}

// =============================================================================
// VÉRIFICATION D'URGENCE
// =============================================================================

bool PhaseDetector::is_emergency(Phase phase, double score, 
                                 const EmotionMap& emotions) const {
    // Phase PEUR avec score élevé = urgence
    if (phase == Phase::PEUR) {
        double peur = get_emotion(emotions, "Peur", 0.0);
        double horreur = get_emotion(emotions, "Horreur", 0.0);
        
        // Urgence si Peur > 0.85 OU Horreur > 0.8 OU score > 5.5
        if (peur > 0.85 || horreur > 0.8 || score > 5.5) {
            return true;
        }
    }
    
    // Phase DEGOUT avec score très élevé
    if (phase == Phase::DEGOUT && score > 4.5) {
        return true;
    }
    
    return false;
}

// =============================================================================
// TRANSITION DE PHASE
// =============================================================================

void PhaseDetector::transition_to(Phase new_phase, const EmotionMap& emotions,
                                  const std::string& reason) {
    if (new_phase == current_phase_) return;
    
    // Calculer la durée dans la phase précédente
    auto now = std::chrono::system_clock::now();
    Duration duration = now - phase_start_time_;
    double duration_seconds = duration.count();
    
    // Créer l'enregistrement de transition
    PhaseTransition transition(
        current_phase_,
        new_phase,
        now,
        duration_seconds,
        emotions,
        reason
    );
    
    transition_history_.push_back(transition);
    
    // Enregistrer la durée pour les stats
    phase_durations_[current_phase_].push_back(duration_seconds);
    
    // Afficher la transition
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "🔄 TRANSITION DE PHASE" << std::endl;
    std::cout << std::string(70, '=') << std::endl;
    std::cout << "   De: " << to_string(current_phase_) << std::endl;
    std::cout << "   À:  " << to_string(new_phase) << std::endl;
    std::cout << "   Durée précédente: " << std::fixed << std::setprecision(1) 
              << duration_seconds << "s" << std::endl;
    std::cout << "   Raison: " << reason << std::endl;
    std::cout << std::string(70, '=') << "\n" << std::endl;
    
    // Mettre à jour l'état
    current_phase_ = new_phase;
    phase_start_time_ = now;
    total_transitions_++;
}

// =============================================================================
// ACCESSEURS
// =============================================================================

const PhaseConfig& PhaseDetector::get_phase_config() const {
    return get_phase_config(current_phase_);
}

const PhaseConfig& PhaseDetector::get_phase_config(Phase phase) const {
    return PHASE_CONFIGS.at(phase);
}

double PhaseDetector::get_time_in_current_phase() const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto duration = std::chrono::system_clock::now() - phase_start_time_;
    return std::chrono::duration<double>(duration).count();
}

// =============================================================================
// ANALYSE DU PROFIL ÉMOTIONNEL
// =============================================================================

EmotionalProfile PhaseDetector::analyze_emotional_profile(const EmotionMap& emotions) const {
    EmotionalProfile profile;
    
    // Valence
    profile.valence = compute_valence(emotions);
    
    // Arousal
    profile.arousal = compute_arousal(emotions);
    
    // Dominance
    profile.dominance = compute_dominance(emotions);
    
    // Variance
    profile.variance = compute_variance(emotions);
    
    // Émotion maximale
    auto max_it = std::max_element(emotions.begin(), emotions.end(),
        [](const auto& a, const auto& b) { return a.second < b.second; });
    
    if (max_it != emotions.end()) {
        profile.max_emotion = max_it->first;
        profile.max_value = max_it->second;
    } else {
        profile.max_emotion = "None";
        profile.max_value = 0.0;
    }
    
    // Moyennes positives/négatives
    double sum_pos = 0.0, sum_neg = 0.0;
    for (const auto& emo : POSITIVE_EMOTIONS) {
        sum_pos += get_emotion(emotions, emo, 0.0);
    }
    for (const auto& emo : NEGATIVE_EMOTIONS) {
        sum_neg += get_emotion(emotions, emo, 0.0);
    }
    
    profile.positive_mean = sum_pos / POSITIVE_EMOTIONS.size();
    profile.negative_mean = sum_neg / NEGATIVE_EMOTIONS.size();
    
    return profile;
}

// =============================================================================
// STATISTIQUES
// =============================================================================

PhaseStatistics PhaseDetector::get_statistics() const {
    std::lock_guard<std::mutex> lock(mutex_);
    
    PhaseStatistics stats;
    stats.current_phase = current_phase_;
    stats.time_in_current = get_time_in_current_phase();
    stats.total_transitions = total_transitions_;
    stats.phase_durations = phase_durations_;
    stats.transition_history = transition_history_;
    
    return stats;
}

std::vector<PhaseTransition> PhaseDetector::get_recent_transitions(size_t n) const {
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (transition_history_.size() <= n) {
        return transition_history_;
    }
    
    return std::vector<PhaseTransition>(
        transition_history_.end() - n,
        transition_history_.end()
    );
}

// =============================================================================
// AFFICHAGE
// =============================================================================

void PhaseDetector::display_status(const EmotionMap& emotions) const {
    std::lock_guard<std::mutex> lock(mutex_);
    
    const auto& config = get_phase_config();
    double duration = get_time_in_current_phase();
    
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "🎭 PHASE ÉMOTIONNELLE: " << to_string(current_phase_) << std::endl;
    std::cout << std::string(70, '=') << std::endl;
    std::cout << "⏱️  Durée dans cette phase: " << std::fixed << std::setprecision(1) 
              << duration << "s" << std::endl;
    
    // Top 3 émotions
    std::vector<std::pair<std::string, double>> emo_vec(emotions.begin(), emotions.end());
    std::partial_sort(emo_vec.begin(), emo_vec.begin() + std::min(size_t(3), emo_vec.size()),
                     emo_vec.end(),
                     [](const auto& a, const auto& b) { return a.second > b.second; });
    
    std::cout << "\n📊 Émotions dominantes:" << std::endl;
    for (size_t i = 0; i < std::min(size_t(3), emo_vec.size()); ++i) {
        std::cout << "   " << std::left << std::setw(25) << emo_vec[i].first
                  << " : " << std::fixed << std::setprecision(3) << emo_vec[i].second
                  << " [" << format_emotion_bar(emo_vec[i].second) << "]" << std::endl;
    }
    
    // Configuration MCEE
    std::cout << "\n⚙️  Coefficients MCEE actifs:" << std::endl;
    std::cout << "   α (feedback externe)    : " << std::fixed << std::setprecision(2) 
              << config.alpha << std::endl;
    std::cout << "   β (feedback interne)    : " << config.beta << std::endl;
    std::cout << "   γ (décroissance)        : " << config.gamma << std::endl;
    std::cout << "   δ (influence souvenirs) : " << config.delta << std::endl;
    std::cout << "   θ (sagesse)             : " << config.theta << std::endl;
    
    std::cout << "\n🎯 Seuils actifs:" << std::endl;
    std::cout << "   Amyghaleon : " << std::fixed << std::setprecision(2) 
              << config.amyghaleon_threshold << std::endl;
    std::cout << "   Consolidation : " << config.memory_consolidation << std::endl;
    std::cout << "   Attention : " << config.attention_focus << std::endl;
    std::cout << "   Apprentissage : " << config.learning_rate << std::endl;
    
    // Historique récent
    if (!transition_history_.empty()) {
        std::cout << "\n📜 Transitions récentes:" << std::endl;
        size_t start = transition_history_.size() > 3 ? transition_history_.size() - 3 : 0;
        for (size_t i = start; i < transition_history_.size(); ++i) {
            const auto& t = transition_history_[i];
            std::cout << "   " << to_string(t.from_phase) << " → " << to_string(t.to_phase)
                      << " (" << std::fixed << std::setprecision(1) << t.duration_previous << "s)"
                      << std::endl;
        }
    }
    
    std::cout << std::string(70, '=') << "\n" << std::endl;
}

// =============================================================================
// FONCTIONS UTILITAIRES
// =============================================================================

EmotionMap emotion_vector_to_map(const EmotionVector& vec) {
    EmotionMap map;
    for (size_t i = 0; i < NUM_EMOTIONS; ++i) {
        map[EMOTION_NAMES[i]] = vec[i];
    }
    return map;
}

EmotionVector emotion_map_to_vector(const EmotionMap& map) {
    EmotionVector vec;
    for (size_t i = 0; i < NUM_EMOTIONS; ++i) {
        vec[i] = get_emotion(map, EMOTION_NAMES[i], 0.0);
    }
    return vec;
}

double compute_valence(const EmotionMap& emotions) {
    double sum_pos = 0.0, sum_neg = 0.0;
    
    for (const auto& emo : POSITIVE_EMOTIONS) {
        sum_pos += get_emotion(emotions, emo, 0.0);
    }
    for (const auto& emo : NEGATIVE_EMOTIONS) {
        sum_neg += get_emotion(emotions, emo, 0.0);
    }
    
    double mean_pos = sum_pos / POSITIVE_EMOTIONS.size();
    double mean_neg = sum_neg / NEGATIVE_EMOTIONS.size();
    
    return mean_pos - mean_neg;
}

double compute_arousal(const EmotionMap& emotions) {
    double sum = 0.0;
    for (const auto& emo : HIGH_AROUSAL_EMOTIONS) {
        sum += get_emotion(emotions, emo, 0.0);
    }
    return sum / HIGH_AROUSAL_EMOTIONS.size();
}

double compute_dominance(const EmotionMap& emotions) {
    double positive = get_emotion(emotions, "Satisfaction") + 
                     get_emotion(emotions, "Triomphe");
    double negative = get_emotion(emotions, "Peur") + 
                     get_emotion(emotions, "Anxiété");
    return positive - negative;
}

std::string format_emotion_bar(double value, size_t width) {
    size_t filled = static_cast<size_t>(value * width);
    size_t empty = width - filled;
    return std::string(filled, '█') + std::string(empty, '░');
}

std::string format_duration(double seconds) {
    std::ostringstream oss;
    if (seconds < 60) {
        oss << std::fixed << std::setprecision(1) << seconds << "s";
    } else if (seconds < 3600) {
        oss << std::fixed << std::setprecision(1) << (seconds / 60.0) << "min";
    } else {
        oss << std::fixed << std::setprecision(1) << (seconds / 3600.0) << "h";
    }
    return oss.str();
}

// =============================================================================
// MÉTHODES PRIVÉES UTILITAIRES
// =============================================================================

double PhaseDetector::mean(const std::vector<double>& values) {
    if (values.empty()) return 0.0;
    return std::accumulate(values.begin(), values.end(), 0.0) / values.size();
}

double PhaseDetector::std_dev(const std::vector<double>& values) {
    if (values.size() < 2) return 0.0;
    
    double m = mean(values);
    double sum_sq = 0.0;
    for (double val : values) {
        double diff = val - m;
        sum_sq += diff * diff;
    }
    
    return std::sqrt(sum_sq / values.size());
}

} // namespace mcee
