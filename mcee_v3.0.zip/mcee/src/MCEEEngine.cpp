/**
 * @file MCEEEngine.cpp
 * @brief Implémentation du moteur principal MCEE
 * @version 3.0
 * @date 2024
 * 
 * Version 3.0 : Architecture MCT/MLT avec patterns dynamiques
 */

#include "MCEEEngine.hpp"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>

namespace mcee {

MCEEEngine::MCEEEngine(const RabbitMQConfig& rabbitmq_config)
    : rabbitmq_config_(rabbitmq_config)
    , phase_detector_(DEFAULT_HYSTERESIS_MARGIN, DEFAULT_MIN_PHASE_DURATION)
    , last_update_time_(std::chrono::steady_clock::now())
    , pattern_start_time_(std::chrono::steady_clock::now())
{
    std::cout << "\n";
    std::cout << "╔══════════════════════════════════════════════════════════════╗\n";
    std::cout << "║           MCEE - Modèle Complet d'Évaluation des États       ║\n";
    std::cout << "║                        Version 3.0                            ║\n";
    std::cout << "║              Architecture MCT/MLT - Patterns Dynamiques       ║\n";
    std::cout << "╚══════════════════════════════════════════════════════════════╝\n";
    std::cout << "\n";

    // Initialiser le système MCT/MLT
    initMemorySystem();

    // Configurer les callbacks legacy (PhaseDetector)
    phase_detector_.setTransitionCallback(
        [this](Phase from, Phase to, double duration) {
            stats_.previous_phase = from;
            stats_.current_phase = to;
            stats_.phase_duration = 0.0;
            stats_.phase_transitions++;
            
            emotion_updater_.setCoefficientsFromPhase(phase_detector_.getCurrentConfig());
        }
    );

    // Configurer Amyghaleon
    amyghaleon_.setEmergencyCallback(
        [this](const EmergencyResponse& response) {
            executeEmergencyAction(response);
            stats_.emergency_triggers++;
        }
    );

    // Configurer le callback d'urgence du module parole
    speech_input_.setUrgencyCallback(
        [this](const std::string& text, double urgency) {
            std::cout << "[MCEEEngine] ⚠ Urgence détectée dans le texte (score=" 
                      << std::fixed << std::setprecision(2) << urgency << ")\n";
            current_feedback_.internal = std::max(current_feedback_.internal, urgency * 0.5);
        }
    );

    // Configurer les callbacks MCT/MLT
    setupCallbacks();

    std::cout << "[MCEEEngine] Moteur v3.0 initialisé avec MCT/MLT + Parole\n";
}

void MCEEEngine::initMemorySystem() {
    // Créer la MCT
    MCTConfig mct_config;
    mct_config.max_size = 60;
    mct_config.time_window_seconds = 30.0;
    mct_config.decay_factor = 0.95;
    mct_config.min_samples_for_signature = 5;
    mct_ = std::make_shared<MCT>(mct_config);
    
    // Créer la MLT avec les patterns de base
    MLTConfig mlt_config;
    mlt_config.min_similarity_threshold = 0.6;
    mlt_config.high_similarity_threshold = 0.85;
    mlt_config.learning_rate = 0.1;
    mlt_config.max_patterns = 100;
    mlt_ = std::make_shared<MLT>(mlt_config);
    
    // Créer le PatternMatcher
    PatternMatcherConfig pm_config;
    pm_config.high_match_threshold = 0.85;
    pm_config.medium_match_threshold = 0.6;
    pm_config.low_match_threshold = 0.4;
    pm_config.hysteresis_margin = 0.1;
    pm_config.min_frames_before_switch = 3;
    pm_config.verbose_logging = true;
    pattern_matcher_ = std::make_shared<PatternMatcher>(mct_, mlt_, pm_config);
    
    std::cout << "[MCEEEngine] Système MCT/MLT initialisé\n";
    std::cout << "[MCEEEngine] MLT: " << mlt_->patternCount() << " patterns de base\n";
}

void MCEEEngine::setupCallbacks() {
    if (!pattern_matcher_) return;
    
    // Callback sur changement de pattern
    pattern_matcher_->setMatchCallback([this](const MatchResult& match) {
        if (match.is_transition) {
            std::cout << "\n[MCEEEngine] ═══ Transition de pattern: " 
                      << current_match_.pattern_name << " → " 
                      << match.pattern_name << " ═══\n";
            std::cout << "[MCEEEngine] Similarité: " << std::fixed << std::setprecision(3) 
                      << match.similarity << ", Confiance: " << match.confidence << "\n\n";
        }
    });
    
    // Callback sur création de pattern
    pattern_matcher_->setNewPatternCallback([this](const std::string& id, const std::string& name) {
        std::cout << "[MCEEEngine] ★ Nouveau pattern créé: " << name << " (id: " << id << ")\n";
    });
    
    // Callback sur transition
    pattern_matcher_->setTransitionCallback([this](const std::string& from, const std::string& to, double prob) {
        stats_.phase_transitions++;
        
        // Enregistrer la durée du pattern précédent
        auto now = std::chrono::steady_clock::now();
        double duration = std::chrono::duration<double>(now - pattern_start_time_).count();
        mlt_->recordActivation(from, duration);
        
        pattern_start_time_ = now;
    });
    
    // Callback MLT sur événements pattern
    if (mlt_) {
        mlt_->setEventCallback([](const PatternEvent& event) {
            std::string type_str;
            switch (event.type) {
                case PatternEvent::Type::CREATED: type_str = "CREATED"; break;
                case PatternEvent::Type::MODIFIED: type_str = "MODIFIED"; break;
                case PatternEvent::Type::MERGED: type_str = "MERGED"; break;
                case PatternEvent::Type::DELETED: type_str = "DELETED"; break;
                case PatternEvent::Type::ACTIVATED: type_str = "ACTIVATED"; break;
                case PatternEvent::Type::DEACTIVATED: type_str = "DEACTIVATED"; break;
            }
            std::cout << "[MLT Event] " << type_str << ": " << event.pattern_name;
            if (!event.details.empty()) {
                std::cout << " - " << event.details;
            }
            std::cout << "\n";
        });
    }
}

MCEEEngine::~MCEEEngine() {
    stop();
}

bool MCEEEngine::start() {
    if (running_.load()) {
        std::cout << "[MCEEEngine] Déjà en cours d'exécution\n";
        return true;
    }

    // Initialiser RabbitMQ
    if (!initRabbitMQ()) {
        std::cerr << "[MCEEEngine] Échec initialisation RabbitMQ\n";
        return false;
    }

    running_.store(true);
    
    // Démarrer les threads de consommation
    emotions_consumer_thread_ = std::thread(&MCEEEngine::emotionsConsumeLoop, this);
    speech_consumer_thread_ = std::thread(&MCEEEngine::speechConsumeLoop, this);

    std::cout << "[MCEEEngine] ✓ Démarré et en attente de messages RabbitMQ\n";
    std::cout << "[MCEEEngine] Émotions: " << rabbitmq_config_.emotions_exchange 
              << " / " << rabbitmq_config_.emotions_routing_key << "\n";
    std::cout << "[MCEEEngine] Parole: " << rabbitmq_config_.speech_exchange 
              << " / " << rabbitmq_config_.speech_routing_key << "\n\n";

    return true;
}

void MCEEEngine::stop() {
    if (!running_.load()) {
        return;
    }

    running_.store(false);

    if (emotions_consumer_thread_.joinable()) {
        emotions_consumer_thread_.join();
    }
    
    if (speech_consumer_thread_.joinable()) {
        speech_consumer_thread_.join();
    }

    std::cout << "[MCEEEngine] Arrêté\n";
    std::cout << "[MCEEEngine] Statistiques finales:\n";
    std::cout << "  - Transitions de phase: " << stats_.phase_transitions << "\n";
    std::cout << "  - Urgences déclenchées: " << stats_.emergency_triggers << "\n";
    std::cout << "  - Souvenirs créés: " << memory_manager_.getMemoryCount() << "\n";
    std::cout << "  - Traumas: " << memory_manager_.getTraumaCount() << "\n";
    std::cout << "  - Textes traités: " << speech_input_.getProcessedCount() << "\n";
    std::cout << "  - Sentiment moyen: " << std::fixed << std::setprecision(2) 
              << speech_input_.getAverageSentiment() << "\n";
}

bool MCEEEngine::initRabbitMQ() {
    try {
        AmqpClient::Channel::OpenOpts opts;
        opts.host = rabbitmq_config_.host;
        opts.port = rabbitmq_config_.port;
        opts.auth = AmqpClient::Channel::OpenOpts::BasicAuth{
            rabbitmq_config_.user, 
            rabbitmq_config_.password
        };

        channel_ = AmqpClient::Channel::Open(opts);

        // === Exchanges ===
        
        // Exchange pour les émotions (entrée)
        channel_->DeclareExchange(
            rabbitmq_config_.emotions_exchange,
            AmqpClient::Channel::EXCHANGE_TYPE_TOPIC,
            false, true, false
        );

        // Exchange pour la parole (entrée)
        channel_->DeclareExchange(
            rabbitmq_config_.speech_exchange,
            AmqpClient::Channel::EXCHANGE_TYPE_TOPIC,
            false, true, false
        );

        // Exchange pour la sortie
        channel_->DeclareExchange(
            rabbitmq_config_.output_exchange,
            AmqpClient::Channel::EXCHANGE_TYPE_TOPIC,
            false, true, false
        );

        // === Queues ===
        
        // Queue pour les émotions
        std::string emotions_queue = channel_->DeclareQueue(
            "mcee_emotions_queue", false, true, false, false
        );
        channel_->BindQueue(
            emotions_queue,
            rabbitmq_config_.emotions_exchange,
            rabbitmq_config_.emotions_routing_key
        );
        emotions_consumer_tag_ = channel_->BasicConsume(
            emotions_queue, "", true, false, false, 1
        );

        // Queue pour la parole
        std::string speech_queue = channel_->DeclareQueue(
            "mcee_speech_queue", false, true, false, false
        );
        channel_->BindQueue(
            speech_queue,
            rabbitmq_config_.speech_exchange,
            rabbitmq_config_.speech_routing_key
        );
        speech_consumer_tag_ = channel_->BasicConsume(
            speech_queue, "", true, false, false, 1
        );

        std::cout << "[MCEEEngine] Connexion RabbitMQ établie\n";
        std::cout << "[MCEEEngine] Queues créées: emotions + speech\n";
        return true;

    } catch (const std::exception& e) {
        std::cerr << "[MCEEEngine] Erreur RabbitMQ: " << e.what() << "\n";
        return false;
    }
}

void MCEEEngine::emotionsConsumeLoop() {
    std::cout << "[MCEEEngine] Boucle de consommation des émotions démarrée\n";

    while (running_.load()) {
        try {
            AmqpClient::Envelope::ptr_t envelope;
            bool received = channel_->BasicConsumeMessage(emotions_consumer_tag_, envelope, 500);

            if (received && envelope) {
                std::string body(envelope->Message()->Body().begin(),
                                envelope->Message()->Body().end());
                
                handleEmotionMessage(body);
                channel_->BasicAck(envelope);
            }

        } catch (const std::exception& e) {
            std::cerr << "[MCEEEngine] Erreur consommation émotions: " << e.what() << "\n";
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void MCEEEngine::speechConsumeLoop() {
    std::cout << "[MCEEEngine] Boucle de consommation de la parole démarrée\n";

    while (running_.load()) {
        try {
            AmqpClient::Envelope::ptr_t envelope;
            bool received = channel_->BasicConsumeMessage(speech_consumer_tag_, envelope, 500);

            if (received && envelope) {
                std::string body(envelope->Message()->Body().begin(),
                                envelope->Message()->Body().end());
                
                handleSpeechMessage(body);
                channel_->BasicAck(envelope);
            }

        } catch (const std::exception& e) {
            std::cerr << "[MCEEEngine] Erreur consommation parole: " << e.what() << "\n";
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void MCEEEngine::handleEmotionMessage(const std::string& body) {
    try {
        json input = json::parse(body);
        
        std::unordered_map<std::string, double> raw_emotions;
        for (const auto& name : EMOTION_NAMES) {
            if (input.contains(name)) {
                raw_emotions[name] = input[name].get<double>();
            } else {
                raw_emotions[name] = 0.0;
            }
        }

        processEmotions(raw_emotions);

    } catch (const std::exception& e) {
        std::cerr << "[MCEEEngine] Erreur parsing JSON émotions: " << e.what() << "\n";
    }
}

void MCEEEngine::handleSpeechMessage(const std::string& body) {
    try {
        json input = json::parse(body);
        
        std::string text = input.value("text", "");
        std::string source = input.value("source", "user");
        double confidence = input.value("confidence", 1.0);

        if (!text.empty()) {
            TextInput text_input;
            text_input.text = text;
            text_input.source = source;
            text_input.confidence = confidence;
            
            // Traiter le texte
            last_speech_analysis_ = speech_input_.processText(text_input);
            
            // Mettre à jour le feedback externe basé sur le texte
            double fb_ext = speech_input_.computeFeedbackExternal(last_speech_analysis_);
            
            {
                std::lock_guard<std::mutex> lock(state_mutex_);
                // Combiner avec le feedback existant (moyenne pondérée)
                current_feedback_.external = current_feedback_.external * 0.3 + fb_ext * 0.7;
            }

            std::cout << "[MCEEEngine] Texte traité, feedback externe ajusté: " 
                      << std::fixed << std::setprecision(2) << current_feedback_.external << "\n";
        }

    } catch (const std::exception& e) {
        std::cerr << "[MCEEEngine] Erreur parsing JSON parole: " << e.what() << "\n";
    }
}

void MCEEEngine::processEmotions(const std::unordered_map<std::string, double>& raw_emotions) {
    std::lock_guard<std::mutex> lock(state_mutex_);
    
    // Sauvegarder l'état précédent
    previous_state_ = current_state_;

    // Convertir en EmotionalState
    current_state_ = rawToState(raw_emotions);

    // Exécuter le pipeline complet
    processPipeline(raw_emotions);
}

void MCEEEngine::processSpeechText(const std::string& text, const std::string& source) {
    // Traiter le texte via SpeechInput
    last_speech_analysis_ = speech_input_.processText(text, source);
    
    // Mettre à jour le feedback externe
    double fb_ext = speech_input_.computeFeedbackExternal(last_speech_analysis_);
    
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        current_feedback_.external = current_feedback_.external * 0.3 + fb_ext * 0.7;
    }
    
    // Créer un contexte pour le souvenir si le texte est significatif
    if (std::abs(last_speech_analysis_.sentiment_score) > 0.3 || 
        last_speech_analysis_.urgency_score > 0.5) {
        std::string context = speech_input_.generateMemoryContext(last_speech_analysis_);
        memory_manager_.recordMemory(current_state_, phase_detector_.getCurrentPhase(), context);
    }

    std::cout << "[MCEEEngine] Texte traité: sentiment=" 
              << std::fixed << std::setprecision(2) << last_speech_analysis_.sentiment_score
              << ", fb_ext=" << current_feedback_.external << "\n";
}

void MCEEEngine::processPipeline(const std::unordered_map<std::string, double>& raw_emotions) {
    // ═══════════════════════════════════════════════════════════════════════
    // PIPELINE V3.0 : MCT → PatternMatcher → MLT
    // ═══════════════════════════════════════════════════════════════════════
    
    // 1. AJOUTER L'ÉTAT À LA MCT
    pushToMCT(current_state_);
    
    // 2. IDENTIFIER LE PATTERN VIA PatternMatcher
    MatchResult match = identifyPattern();
    
    // Stocker le match courant
    MatchResult previous_match = current_match_;
    current_match_ = match;
    
    // Log si transition
    if (match.is_transition || match.pattern_id != previous_match.pattern_id) {
        std::cout << "\n[MCEEEngine] Pattern actif: " << match.pattern_name 
                  << " (sim=" << std::fixed << std::setprecision(3) << match.similarity 
                  << ", conf=" << match.confidence << ")\n";
    }
    
    // 3. APPLIQUER LES COEFFICIENTS DU PATTERN
    EmotionalState processed_state = applyPatternCoefficients(current_state_, match);
    
    // 4. RÉCUPÉRER LES SOUVENIRS PERTINENTS (legacy)
    Phase current_phase = phase_detector_.getCurrentPhase();
    auto memories = memory_manager_.queryRelevantMemories(current_phase, current_state_, 10);
    
    for (auto& mem : memories) {
        memory_manager_.updateActivation(mem, current_state_);
    }
    
    // 5. VÉRIFIER AMYGHALEON (court-circuit d'urgence)
    handleEmergency(match);
    
    // 6. CALCULER LE DELTA TEMPS
    auto now = std::chrono::steady_clock::now();
    double delta_t = std::chrono::duration<double>(now - last_update_time_).count();
    last_update_time_ = now;
    
    // 7. METTRE À JOUR LA SAGESSE
    updateWisdom();
    
    // 8. CONFIGURER EmotionUpdater AVEC LES COEFFICIENTS DU PATTERN
    PhaseConfig pattern_config;
    pattern_config.alpha = match.alpha;
    pattern_config.beta = match.beta;
    pattern_config.gamma = match.gamma;
    pattern_config.delta = match.delta;
    pattern_config.theta = match.theta;
    pattern_config.amyghaleon_threshold = match.emergency_threshold;
    pattern_config.memory_consolidation = match.memory_trigger_threshold;
    
    emotion_updater_.setCoefficientsFromPhase(pattern_config);
    
    // 9. CALCULER L'INFLUENCE DES SOUVENIRS
    auto memory_influences = memory_manager_.computeMemoryInfluences(
        memories, match.delta
    );
    
    // 10. METTRE À JOUR LES ÉMOTIONS
    emotion_updater_.updateAllEmotions(
        current_state_,
        current_feedback_,
        delta_t,
        memory_influences,
        wisdom_
    );
    
    // 11. CALCULER LA VARIANCE GLOBALE
    current_state_.variance_global = emotion_updater_.computeGlobalVariance(
        current_state_, memories
    );
    
    // 12. CALCULER E_GLOBAL
    current_state_.E_global = emotion_updater_.computeEGlobal(
        current_state_,
        previous_state_.E_global,
        current_state_.variance_global
    );
    
    // 13. REPOUSSER L'ÉTAT TRAITÉ DANS LA MCT (feedback loop)
    if (mct_) {
        if (!last_speech_analysis_.raw_text.empty()) {
            mct_->pushWithSpeech(current_state_, 
                                 last_speech_analysis_.sentiment_score,
                                 last_speech_analysis_.arousal_score,
                                 last_speech_analysis_.raw_text);
        } else {
            mct_->push(current_state_);
        }
    }
    
    // 14. CONSOLIDER EN MLT SI SIGNIFICATIF
    consolidateToMLT();
    
    // 15. ENREGISTRER UN SOUVENIR SI SIGNIFICATIF
    if (current_state_.getMeanIntensity() > match.memory_trigger_threshold) {
        auto [dominant, value] = current_state_.getDominant();
        std::string context = "Pattern:" + match.pattern_name + "_" + dominant;
        memory_manager_.recordMemory(current_state_, current_phase, context);
    }
    
    // 16. PUBLIER L'ÉTAT
    publishState();
    
    // 17. CALLBACK
    if (on_state_change_) {
        on_state_change_(current_state_, match.pattern_name);
    }
    
    // Afficher l'état
    printState();
}

void MCEEEngine::printState() const {
    auto [dominant, value] = current_state_.getDominant();
    
    std::cout << "\n[MCEEEngine] État émotionnel mis à jour:\n";
    std::cout << "  Pattern   : " << current_match_.pattern_name 
              << " (sim=" << std::fixed << std::setprecision(2) << current_match_.similarity 
              << ", conf=" << current_match_.confidence << ")\n";
    std::cout << "  Dominant  : " << dominant << " = " 
              << std::fixed << std::setprecision(3) << value << "\n";
    std::cout << "  E_global  : " << std::fixed << std::setprecision(3) 
              << current_state_.E_global << "\n";
    std::cout << "  Variance  : " << std::fixed << std::setprecision(3) 
              << current_state_.variance_global << "\n";
    std::cout << "  Valence   : " << std::fixed << std::setprecision(3) 
              << current_state_.getValence() << "\n";
    std::cout << "  Intensité : " << std::fixed << std::setprecision(3) 
              << current_state_.getMeanIntensity() << "\n";
    
    // Afficher métriques MCT si disponible
    if (mct_ && !mct_->empty()) {
        std::cout << "  MCT       : size=" << mct_->size() 
                  << ", stability=" << std::fixed << std::setprecision(2) << mct_->getStability()
                  << ", trend=" << mct_->getTrend() << "\n";
    }
    std::cout << "\n";
}

void MCEEEngine::publishState() {
    if (!channel_) return;

    try {
        json output;
        
        // Émotions
        for (size_t i = 0; i < NUM_EMOTIONS; ++i) {
            output["emotions"][EMOTION_NAMES[i]] = current_state_.emotions[i];
        }

        // Méta-données
        output["E_global"] = current_state_.E_global;
        output["variance_global"] = current_state_.variance_global;
        output["valence"] = current_state_.getValence();
        output["intensity"] = current_state_.getMeanIntensity();
        
        auto [dominant, value] = current_state_.getDominant();
        output["dominant"] = dominant;
        output["dominant_value"] = value;

        // Pattern actif (v3.0)
        output["pattern"]["id"] = current_match_.pattern_id;
        output["pattern"]["name"] = current_match_.pattern_name;
        output["pattern"]["similarity"] = current_match_.similarity;
        output["pattern"]["confidence"] = current_match_.confidence;
        output["pattern"]["is_new"] = current_match_.is_new_pattern;
        output["pattern"]["is_transition"] = current_match_.is_transition;

        // Coefficients actifs (du pattern)
        output["coefficients"]["alpha"] = current_match_.alpha;
        output["coefficients"]["beta"] = current_match_.beta;
        output["coefficients"]["gamma"] = current_match_.gamma;
        output["coefficients"]["delta"] = current_match_.delta;
        output["coefficients"]["theta"] = current_match_.theta;
        output["coefficients"]["emergency_threshold"] = current_match_.emergency_threshold;

        // Phase legacy (pour compatibilité)
        output["phase"] = phaseToString(phase_detector_.getCurrentPhase());
        output["phase_duration"] = phase_detector_.getPhaseDuration();

        // Métriques MCT
        if (mct_) {
            output["mct"]["size"] = mct_->size();
            output["mct"]["stability"] = mct_->getStability();
            output["mct"]["volatility"] = mct_->getVolatility();
            output["mct"]["trend"] = mct_->getTrend();
        }

        // Statistiques
        output["stats"]["pattern_transitions"] = stats_.phase_transitions;
        output["stats"]["emergency_triggers"] = stats_.emergency_triggers;
        output["stats"]["wisdom"] = wisdom_;
        
        if (mlt_) {
            output["stats"]["total_patterns"] = mlt_->patternCount();
        }
        if (pattern_matcher_) {
            output["stats"]["total_matches"] = pattern_matcher_->getTotalMatches();
            output["stats"]["patterns_created"] = pattern_matcher_->getPatternsCreated();
        }

        std::string body = output.dump();
        channel_->BasicPublish(
            rabbitmq_config_.output_exchange,
            rabbitmq_config_.output_routing_key,
            AmqpClient::BasicMessage::Create(body),
            false, false
        );

    } catch (const std::exception& e) {
        std::cerr << "[MCEEEngine] Erreur publication: " << e.what() << "\n";
    }
}

void MCEEEngine::setFeedback(double external, double internal) {
    std::lock_guard<std::mutex> lock(state_mutex_);
    current_feedback_.external = std::clamp(external, -1.0, 1.0);
    current_feedback_.internal = std::clamp(internal, -1.0, 1.0);
}

void MCEEEngine::setStateCallback(StateCallback callback) {
    on_state_change_ = std::move(callback);
}

void MCEEEngine::updateWisdom() {
    // La sagesse augmente avec l'expérience (nombre de transitions)
    // et diminue en phase PEUR
    Phase phase = phase_detector_.getCurrentPhase();
    const auto& config = phase_detector_.getCurrentConfig();

    if (phase == Phase::PEUR) {
        wisdom_ *= 0.95;  // Décroissance en phase PEUR
    } else {
        wisdom_ += config.learning_rate * 0.001;  // Croissance lente
    }

    wisdom_ = std::clamp(wisdom_, 0.0, 1.0);
    stats_.wisdom = wisdom_;
}

void MCEEEngine::executeEmergencyAction(const EmergencyResponse& response) {
    std::cout << "\n[MCEEEngine] ⚡ Exécution action d'urgence: " << response.action << "\n";

    // Actions spécifiques selon le type
    if (response.action == "FUITE") {
        // Préparer le système pour une réponse de fuite
        current_feedback_.internal = 0.8;  // Stress élevé
    } else if (response.action == "BLOCAGE") {
        // Bloquer temporairement les mises à jour
        current_feedback_.internal = 1.0;
    } else if (response.action == "ALERTE") {
        // Mode alerte
        current_feedback_.internal = 0.5;
    }
}

void MCEEEngine::forcePhaseTransition(Phase phase, const std::string& reason) {
    std::lock_guard<std::mutex> lock(state_mutex_);
    phase_detector_.forceTransition(phase, reason);
    emotion_updater_.setCoefficientsFromPhase(phase_detector_.getCurrentConfig());
}

bool MCEEEngine::loadConfig(const std::string& config_path) {
    bool success = phase_detector_.loadConfig(config_path);
    if (success) {
        emotion_updater_.setCoefficientsFromPhase(phase_detector_.getCurrentConfig());
    }
    return success;
}

EmotionalState MCEEEngine::rawToState(
    const std::unordered_map<std::string, double>& raw) const 
{
    EmotionalState state;
    
    for (size_t i = 0; i < NUM_EMOTIONS; ++i) {
        auto it = raw.find(EMOTION_NAMES[i]);
        if (it != raw.end()) {
            state.emotions[i] = std::clamp(it->second, 0.0, 1.0);
        }
    }

    return state;
}

// ═══════════════════════════════════════════════════════════════════════════
// MÉTHODES MCT/MLT V3.0
// ═══════════════════════════════════════════════════════════════════════════

void MCEEEngine::pushToMCT(const EmotionalState& state) {
    if (!mct_) return;
    
    if (!last_speech_analysis_.raw_text.empty()) {
        mct_->pushWithSpeech(state, 
                             last_speech_analysis_.sentiment_score,
                             last_speech_analysis_.arousal_score,
                             last_speech_analysis_.raw_text);
    } else {
        mct_->push(state);
    }
}

MatchResult MCEEEngine::identifyPattern() {
    if (!pattern_matcher_) {
        // Fallback si pas de PatternMatcher
        MatchResult fallback;
        fallback.pattern_name = "DEFAULT";
        fallback.similarity = 0.0;
        fallback.confidence = 0.0;
        fallback.alpha = 0.3;
        fallback.beta = 0.2;
        fallback.gamma = 0.15;
        fallback.delta = 0.1;
        fallback.theta = 0.25;
        fallback.emergency_threshold = 0.8;
        fallback.memory_trigger_threshold = 0.5;
        return fallback;
    }
    
    return pattern_matcher_->match();
}

EmotionalState MCEEEngine::applyPatternCoefficients(const EmotionalState& raw_state, 
                                                     const MatchResult& match) {
    EmotionalState result = raw_state;
    
    // Les coefficients sont appliqués via EmotionUpdater dans processPipeline
    // Cette méthode peut être utilisée pour un pré-traitement si nécessaire
    
    // Pondérer l'état par la confiance du match
    double confidence_factor = 0.5 + 0.5 * match.confidence;
    
    for (size_t i = 0; i < NUM_EMOTIONS; ++i) {
        result.emotions[i] *= confidence_factor;
    }
    
    return result;
}

void MCEEEngine::consolidateToMLT() {
    if (!mct_ || !mlt_ || !pattern_matcher_) return;
    
    // Vérifier si l'état actuel est significatif
    double intensity = current_state_.getMeanIntensity();
    double stability = mct_->getStability();
    
    bool is_significant = (intensity > current_match_.memory_trigger_threshold) ||
                          (std::abs(last_speech_analysis_.sentiment_score) > 0.5) ||
                          (last_speech_analysis_.urgency_score > 0.7);
    
    if (!is_significant) return;
    
    // Si stable et significatif, renforcer le pattern actuel
    if (stability > 0.6 && !current_match_.pattern_id.empty()) {
        auto sig_opt = mct_->extractSignature();
        if (sig_opt) {
            // Mettre à jour le pattern avec la nouvelle signature
            double feedback = (last_speech_analysis_.sentiment_score + 1.0) / 2.0; // [0,1]
            mlt_->updatePattern(current_match_.pattern_id, *sig_opt, feedback);
        }
    }
    
    // Déclencher une passe d'apprentissage périodiquement
    if (stats_.phase_transitions % 10 == 0 && stats_.phase_transitions > 0) {
        mlt_->runLearningPass();
    }
}

void MCEEEngine::handleEmergency(const MatchResult& match) {
    // Vérifier le seuil d'urgence du pattern
    double max_emotion = 0.0;
    for (const auto& e : current_state_.emotions) {
        max_emotion = std::max(max_emotion, e);
    }
    
    // Récupérer les souvenirs pertinents
    Phase current_phase = phase_detector_.getCurrentPhase();
    auto memories = memory_manager_.queryRelevantMemories(current_phase, current_state_, 5);
    
    if (amyghaleon_.checkEmergency(current_state_, memories, match.emergency_threshold)) {
        auto response = amyghaleon_.triggerEmergencyResponse(current_state_, current_phase);
        
        // Créer un trauma potentiel si pattern est PEUR ou similaire
        if (match.pattern_name.find("PEUR") != std::string::npos ||
            match.pattern_name.find("FEAR") != std::string::npos) {
            memory_manager_.createPotentialTrauma(current_state_);
        }
        
        // Court-circuiter et publier l'état d'urgence
        publishState();
    }
}

std::string MCEEEngine::getCurrentPatternName() const {
    if (!current_match_.pattern_name.empty()) {
        return current_match_.pattern_name;
    }
    return phaseToString(phase_detector_.getCurrentPhase());
}

std::string MCEEEngine::getCurrentPatternId() const {
    return current_match_.pattern_id;
}

bool MCEEEngine::loadPatterns(const std::string& path) {
    if (!mlt_) return false;
    return mlt_->loadFromFile(path);
}

bool MCEEEngine::savePatterns(const std::string& path) const {
    if (!mlt_) return false;
    return mlt_->saveToFile(path);
}

void MCEEEngine::forcePattern(const std::string& pattern_name, const std::string& reason) {
    if (!mlt_ || !pattern_matcher_) return;
    
    auto pattern = mlt_->getPatternByName(pattern_name);
    if (pattern) {
        // Mettre à jour le match courant
        current_match_.pattern_id = pattern->id;
        current_match_.pattern_name = pattern->name;
        current_match_.similarity = 1.0;
        current_match_.confidence = pattern->confidence;
        current_match_.alpha = pattern->alpha;
        current_match_.beta = pattern->beta;
        current_match_.gamma = pattern->gamma;
        current_match_.delta = pattern->delta;
        current_match_.theta = pattern->theta;
        current_match_.emergency_threshold = pattern->emergency_threshold;
        current_match_.memory_trigger_threshold = pattern->memory_trigger_threshold;
        
        // Notifier le PatternMatcher
        pattern_matcher_->notifyPatternChange(pattern->id);
        
        std::cout << "[MCEEEngine] Pattern forcé: " << pattern_name 
                  << " (raison: " << reason << ")\n";
    }
}

std::string MCEEEngine::createPatternFromCurrent(const std::string& name, 
                                                  const std::string& description) {
    if (!pattern_matcher_) return "";
    return pattern_matcher_->forceCreatePattern(name, description);
}

void MCEEEngine::provideFeedback(double feedback) {
    if (!pattern_matcher_) return;
    pattern_matcher_->provideFeedback(feedback);
}

void MCEEEngine::runLearning() {
    if (!mlt_) return;
    mlt_->runLearningPass();
    std::cout << "[MCEEEngine] Passe d'apprentissage MLT terminée\n";
}

} // namespace mcee
